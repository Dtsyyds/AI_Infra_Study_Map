# 证据工具增量加固

run_id：20261026T031046Z-evidence-hardening。本轮范围为实验驱动器、交付包一致性校验及反例测试，已通过；项目总体仍PARTIAL。真实模型调用0，未启动PG/API/Docker服务。不是外部独立验收。

## 修改

- 实验在HTTP前写SUBMISSION_INTENT，202后写ACCEPTED，最终写OBSERVATION_FINISHED；JSONL flush+fsync。意图不等于受理，受理不等于任务成功。原始Idempotency-Key/请求/Task ID可用于后续核查。
- load/evaluate由submit_observe统一在finally保存结果；取消写OBSERVATION_ERROR后继续抛出CancelledError，不把取消吞成成功，也不再由调用方重复追加。SIGKILL不能执行finally，此时由意图/受理日志保留未决身份，不伪造终态或自动重提。
- Runtime SUCCEEDED但缺Artifact不算完整实验成功。Artifact大小与SHA-256仍必须一致。
- 已有实验配置、raw、事件日志或NOT_RUN记录时，在任何预检/写入前拒绝覆盖，要求新run或attempt。
- 模型预检将负载标为SEPARATE_EXPERIMENT，移除固定actual_load_tasks=0，避免与已完成负载混淆。
- 归档校验重新核对完整文件清单、run身份、source清单、JUnit实际testcase计数、被测源码快照与命令、真实日志/实验目录存在性。不能只信changed_since_test=[]或missing=[]等自报字段。哈希仍不是真实性签名。

## 验证

- tests/unit + tests/repair：112 passed，零skip/error/failure。包含HTTP受理前后取消、独立子进程SIGKILL、缺Artifact，以及重新计算所有hash后仍存在的漏文件/缺日志/源码变化/虚报JUnit等反例。
- Ruff通过，mypy通过83个源码文件。
- 加强后的校验器只读复核上一完整验收包：PASS，1541文件，原179测试计数一致，archive SHA256保持6822906a55b98d6c6d0b83258fdc54e6da69afc7faa9531576fcae7e1553338f。旧包未修改。
- 初次沙箱执行未完成；最小asyncio.to_thread读文件探针也超时。后续获准在沙箱外运行上述112项，不把未完成尝试算通过。

112是本轮单元/数据契约集合；179是上一轮完整PG/Docker/MCP回归。不能相加作为总覆盖或宣称本轮已完整实跑196项。本轮没有重跑270次负载、新事件日志的真实HTTP/PG整合仍需在下一次真实负载中核验。旧负载108成功/162配额拒绝仍是原实验事实。

## 下一阶段

优先增加独立的配额内持续负载：并发1/2/3、分轮记录成功吞吐及排队/执行/总耗时，不更改原并发1/5/10过载实验及配额，也不将两组分母合并。真实模型dev smoke需另外明确后端、模型、安全注入变量和有界预算；不得把人工参考patch或Fake当模型能力。外部审查与本人独立修改仍未完成。

本轮增量包包含当前源码、补丁、112项证据、该报告以及原完整包；源码与报告hash见增量manifest。它是增量复核材料，不替代基线原始运行证据或全项目验收。
