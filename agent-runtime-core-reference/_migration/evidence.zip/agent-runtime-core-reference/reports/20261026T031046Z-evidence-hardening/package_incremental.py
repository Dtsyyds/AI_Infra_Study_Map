"""Bundle this scoped change plus the immutable full baseline; no acceptance promotion."""
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path
from xml.etree import ElementTree

root = Path.cwd()
report = Path(__file__).resolve().parent
run = report.name
output = root / 'delivery' / run
baseline_run = '20261026T021326Z-docker-free-validation'
baseline = root / 'delivery' / baseline_run

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def copy(source, dest):
    assert source.is_file() and not source.is_symlink()
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)

assert not output.exists(), 'never overwrite an existing delivery'
assert not git('status','--porcelain'), 'commit source and documentation before bundling'
validated = json.loads((report/'validated-source.json').read_text())
source = {p:sha(Path(p).read_bytes()) for p in git('ls-files').splitlines()}
protected = {p:h for p,h in source.items() if p.startswith(('core/','runtime/','api/','config/','tests/','deploy/','examples/'))}
assert protected == validated, 'code/test changed after scoped validation'
base_hash = (baseline/'acceptance_bundle.sha256').read_text().split()[0]
assert sha((baseline/'acceptance_bundle.tar.gz').read_bytes()) == base_hash
output.mkdir(parents=True)
for path in source:
    copy(root/path,output/'source'/path)
shutil.copytree(report,output/'reports'/run)
for name in ['acceptance_bundle.tar.gz','acceptance_bundle.sha256','FINAL_REPORT.md','source_manifest.json']:
    copy(baseline/name, output/'baseline'/name)
copy(report/'FINAL_REPORT.md',output/'FINAL_REPORT.md')
(output/'changes.patch').write_text(git('diff','c6e5024e051f40802b850d40b9fdfe5437b1c453','HEAD')+'\n')
write(output/'source_manifest.json',{'commit':git('rev-parse','HEAD'),'dirty':False,'files_sha256':source,'scope':'incremental evidence tools; no full runtime rerun','validated_source_snapshot':f'reports/{run}/validated-source.json'})
write(output/'validation_scope.json',{'run_id':run,'validation':'PASS_UNIT_AND_DATA_CONTRACTS','full_runtime_rerun':False,'baseline_run_id':baseline_run,'baseline_archive_sha256':base_hash,'model_calls':0,'external_acceptance':'NOT_PERFORMED'})
write(output/'evidence_manifest.json',{'run_id':run,'files_sha256':{str(p.relative_to(output)):sha(p.read_bytes()) for p in sorted(output.rglob('*')) if p.is_file()}})
archive=output/'incremental_bundle.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(output.rglob('*')):
        if p.is_file() and p != archive:
            assert not p.is_symlink()
            tar.add(p,arcname=run+'/'+str(p.relative_to(output)),recursive=False)
checksum=sha(archive.read_bytes())
(output/'incremental_bundle.sha256').write_text(checksum+'  incremental_bundle.tar.gz\n')
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();names=[m.name for m in members]
    assert len(names)==len(set(names)) and all(m.isfile() for m in members)
    def content(name):
        stream=tar.extractfile(run+'/'+name)
        assert stream is not None
        return stream.read()
    inventory=json.loads(content('evidence_manifest.json'))['files_sha256']
    assert set(names)=={run+'/'+p for p in inventory}|{run+'/evidence_manifest.json'}
    for name, expected in inventory.items():
        assert sha(content(name))==expected,name
    snapshot=json.loads(content('source_manifest.json'))
    for name, expected in snapshot['files_sha256'].items():
        assert sha(content('source/'+name))==expected
    assert sha(content('baseline/acceptance_bundle.tar.gz'))==base_hash
    suite=ElementTree.fromstring(content(f'reports/{run}/contracts-final.xml'))
    cases=suite.findall('testsuite/testcase')
    assert len(cases)==112 and all(not any(c.find(t) is not None for t in ('failure','error','skipped')) for c in cases)
write(output/'bundle_validation.json',{'integrity_status':'PASS','scope':'incremental archive hashes/source consistency; 112 scoped tests, not a full runtime rerun','verified_files':len(inventory),'source_commit':git('rev-parse','HEAD'),'archive_sha256':checksum,'baseline_archive_sha256':base_hash,'external_acceptance':'NOT_PERFORMED'})
print(json.dumps({'bundle':str(archive),'sha256':checksum,'verified_files':len(inventory),'scoped_tests_passed':112,'integrity_status':'PASS'},indent=2))
