import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path

from config.settings import settings
from runtime.storage.store import Store

ROOT = Path('reports/20261022-reference')


def ids(value):
    found = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if key.endswith('task_id') and isinstance(child, str):
                found.add(child)
            else:
                found.update(ids(child))
    elif isinstance(value, list):
        for child in value:
            found.update(ids(child))
    return found


async def main():
    demo = json.loads((ROOT/'demo-results.json').read_text())
    store = Store(settings.database_url.get_secret_value())
    snapshots = []
    for task_id in sorted(ids(demo)):
        row = await store.snapshot(task_id)
        snapshots.append({key:row[key] for key in ('task_id','status','version','checkpoint')})
    counts = {}
    async with store.connection() as conn:
        for name in ['D_idempotent','D_unsafe','D_queryable']:
            task_id = demo[name]['task_id']
            row = await (await conn.execute('SELECT (SELECT count(*) FROM arc_business.requests WHERE task_id=%s) AS requests,(SELECT count(*) FROM arc_business.effects WHERE task_id=%s) AS effects',(task_id,task_id))).fetchone()
            assert row == demo[name]['business_counts'], (name,row)
            counts[name]=row
    result = {'observed_at':datetime.now(UTC).isoformat(),'postgresql_restarted':True,'all_saved_task_ids_found':True,'tasks':snapshots,'independent_effect_counts_unchanged':counts}
    (ROOT/'restart-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({'tasks_found':len(snapshots),'external_counts_unchanged':True}))


asyncio.run(main())
