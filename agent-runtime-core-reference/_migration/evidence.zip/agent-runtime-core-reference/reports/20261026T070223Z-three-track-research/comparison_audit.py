"""Independent read-only reconciliation of experiment slots and external business facts."""
import asyncio
import hashlib
import json
from pathlib import Path
from examples.reliability_comparison import summarize, external_facts
from config.settings import settings
from runtime.storage.store import Store

OUT=Path(__file__).resolve().parent
async def main():
    root=OUT/'reliability-comparison'
    plan=json.loads((root/'plan.json').read_text())
    rows=[json.loads(x) for x in (root/'raw.jsonl').read_text().splitlines()]
    events=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
    summary=json.loads((root/'summary.json').read_text())
    assert {k:v for k,v in summary.items() if k!='new_model_reservations'}==summarize(rows,plan['repeats'])
    assert len(rows)==36 and len({r['task_id'] for r in rows})==36
    assert len(events)==72
    for i,slot in enumerate(plan['slots']):
        assert events[2*i]['event']=='TRIAL_STARTED' and events[2*i+1]['event']=='TRIAL_FINISHED'
        assert events[2*i]['slot']==events[2*i+1]['slot']==slot
        assert {key:rows[i][key] for key in slot}==slot
    store=Store(settings.database_url.get_secret_value())
    total_requests=total_effects=0
    for row in rows:
        facts=await external_facts(store,row['task_id'])
        assert facts==row['external_facts']
        assert len(facts['requests'])==row['requests'] and len(facts['effects'])==row['effects']
        assert all(e['report']==plan['request_report'] for e in facts['effects'])
        assert all(Path(log).is_file() for log in row['logs'])
        total_requests+=len(facts['requests']);total_effects+=len(facts['effects'])
    async with store.connection() as conn:
        active=await (await conn.execute("SELECT count(*) AS n FROM arc_ref.tasks WHERE principal_id='demo-reviewer' AND status IN ('QUEUED','RUNNING','NEEDS_REVIEW')")).fetchone()
        calls=await (await conn.execute("SELECT count(*) AS n FROM arc_ref.model_calls WHERE task_id=ANY(%s::uuid[])",([r['task_id'] for r in rows],))).fetchone()
    assert active['n']==calls['n']==0
    result={'integrity_status':'PASS','trial_count':len(rows),'event_count':len(events),
        'external_requests':total_requests,'external_effects':total_effects,
        'duplicate_effects':sum(r['effects']-1 for r in rows),'model_reservations_for_trials':calls['n'],
        'active_demo_tasks':active['n'],'all_payloads_equal':True,'all_process_logs_present':True,
        'raw_sha256':hashlib.sha256((root/'raw.jsonl').read_bytes()).hexdigest(),
        'scope':'fixed constructed fault/control comparison; consistency not external acceptance'}
    (OUT/'comparison-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
asyncio.run(main())
