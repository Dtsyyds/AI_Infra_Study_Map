# 三项研究首轮结果

run：20261026T070223Z-three-track-research。研究阶段可交付；项目总体PARTIAL。真实模型尚未授权/未执行，个人练习仅准备任务书、尚未由本人完成，外部验收NOT_PERFORMED。

## R1：真实模型单dev闭环的离线准备

已提供examples.model_smoke_plan，冻结case-01 dev的Manifest、镜像、runner、测试套件、提示词和Patch Schema哈希。拒绝holdout、拒绝覆盖输出，不读取模型密钥或发网络请求。草案为单Task、最多3候选/请求、每次最大2048输出token、100000本地token预留单位；这是待授权配置，不是已经批准的预算或金额承诺。实际模型开关false、请求/token预算0。

已核对[OpenAI Structured Outputs官方文档](https://developers.openai.com/api/docs/guides/structured-outputs)，当前Schema的对象required/additionalProperties本地检查通过。特定模型/账号/temperature/输出上限的实际兼容性未验证；不会从Mock通过推导API成功。已有独立Harness收据经重算仍匹配当前资产，但真实smoke启动时仍需按新run重新确认资格。

结果：model-smoke-plan.json，状态PREPARED_NOT_AUTHORIZED。未来需要明确模型、可信秘密变量注入方式和正预算；先单dev真实任务，再单独决定72矩阵。成功必须真实候选、当前可信PASS、DELIVERED及Artifact/provider/usage证据齐全；失败也保留，不用gold或Fake补成功。

## R2：三种恢复策略的受控比较

问题：独立业务服务已提交外部效果，HTTP结果尚未返回时SIGKILL调用进程。使用数据库已提交屏障确认时机；三组用同一报告、同一本地服务，各试验独立Task/key。stable-key-only组预先fsync key文件，没有Runtime ledger；volatile组重启换key；Runtime组按持久Action/效果类别恢复。

实际完成36样本：6无故障控制，各为一次请求和一次效果；30固定屏障崩溃样本如下（每单元n=5）。

| 恢复策略 | 幂等服务：请求/效果/额外效果 | unsafe服务：请求/效果/额外效果 | unsafe自动恢复状态 |
|---|---|---|---|
| volatile_key | 10/10/5 | 10/10/5 | 5次返回成功，但重复生效 |
| stable_key_only | 10/5/0 | 10/10/5 | 5次返回成功，但重复生效 |
| Runtime | 10/5/0 | 5/5/0 | 5次NEEDS_REVIEW；之后显式测试操作员确认5次，无新增派发 |

独立只读业务表核对：36唯一Task、72实验事件、61请求、51效果、15额外效果（均在直接调用对照组）、本批模型预留0、实验后demo活任务0。所有外部报告payload相同，所有引用的独立进程日志存在；summarize从raw重算一致。证据：reliability-comparison/plan.json、raw.jsonl、events.jsonl、summary.json、comparison-audit.json；每条raw保存外部请求/效果事实及日志引用。raw SHA-256：73388ff1f0bd630f48723f92767366a0e62080ed2c2ac2360946c90b18c0134f。

实验执行commit bb00cf7，后续7273b4c只澄清两处描述，不改变实验逻辑。原raw中的“identity/FK”措辞保留：直接调用组的Task实际仅用于实验身份关联，arc_business.task_id没有外键约束；后续源码已删除FK措辞。业务payload、派发策略、故障时机和计数均未改变，没有覆盖原数据。

可支持的结论：稳定key的去重依赖外部服务契约；对于本次无幂等的已提交效果窗口，Runtime保留UNKNOWN/NEEDS_REVIEW并停止自动重发，代价是需要显式对账。幂等服务下stable-key-only与Runtime都去重，不能把服务去重能力全部归因于Runtime。

边界：这是局部L2/L3发布恢复探针，直接调用组不执行完整Agent流程。模拟操作员由可信测试控制器在检查独立效果后显式确认，不是全自动恢复。五次重复证明固定时机可复现，不是生产故障概率；不声明通用exactly-once、性能提升或优于主流框架。summary中automatic_successes表示调用方完成声明，须结合duplicate_effects理解，重复生效的返回成功不算业务正确。

## R3：个人独立修改练习

exercises/observation_diagnosis/README.md给出只读诊断中断提交日志的要求，附三个合成输入和空白MY_WORK记录。命令实现、本人测试与个人结论均未生成。本人需要定义输出契约、先写失败测试、实现最小命令并解释未知/冲突边界及只读保证。

状态：SPEC_READY_USER_NOT_STARTED；个人掌握NOT_ASSESSED。这些准备不是本人的独立代码贡献，需本人完成后独立复核。

## 验证与交付边界

首轮完整pytest 218通过、零失败/零跳过（final-test-results.xml）。最后两处描述修改后的最终源码复验同为218 passed、零失败/零跳过（114.69秒）；证据为final-test-results-2.xml及commands.jsonl，被测commit 7273b4c。旧测试记录保留，不累加测试数量。Ruff、mypy记录于对应日志。源码hash与最终JUnit在打包时逐文件比对。

本阶段未重复270负载或整套历史独立故障矩阵。上一轮steady完整包原件放在新包history/，其内保留更早基线与证据加固包，所有原包hash不变。本轮不推送、不调用真实模型、不在宿主执行候选。

最终资源清理PASS：API/业务服务/PG均已停止，三个端口关闭、项目容器0、数据库保留，见resource-cleanup-final.json；早先一次停止证据resource-cleanup.json也保留。API/业务服务/PG按本轮启动身份停止，数据库保留，精确项目标签容器检查不会以UNKNOWN冒充不存在。归档校验仅证明一致性，不代签外部验收。

恢复入口：resume.md。下一步由本人开展练习；另获明确模型/正预算后执行单dev真实smoke；随后由独立复核方检查代码、证据和本人解释。
