"""Read-only verification after stopping only this run's project services."""
import json
import socket
import subprocess
from datetime import datetime,UTC
from pathlib import Path
from runtime.tools.docker_backend import PROJECT_LABEL

out=Path(__file__).resolve().parent
services=json.loads(Path('reports/services.json').read_text())
ports={}
for port in (18081,18082,55439):
    with socket.socket() as probe:
        code=probe.connect_ex(('127.0.0.1',port))
    ports[str(port)]={'connect_errno':code,'listening':code==0}
pg=subprocess.run(['.postgres/bin/pg_ctl','-D',str(Path('.pgdata').resolve()),'status'],capture_output=True,text=True)
docker=subprocess.run(['docker','ps','--all','--quiet','--filter',f'label={PROJECT_LABEL}=reference'],capture_output=True,text=True)
result={'observed_at':datetime.now(UTC).isoformat(),'services':services,'ports':ports,
    'postgres_status_exit_code':pg.returncode,'postgres_status_stdout':pg.stdout,'postgres_status_stderr':pg.stderr,
    'database_files_preserved':Path('.pgdata/PG_VERSION').is_file(),
    'docker_project_inspection':{'exit_code':docker.returncode,'remaining_container_ids':docker.stdout.split(),
        'stderr':docker.stderr,'scope':'existing exact project label; no global cleanup'},
    'unrelated_resources_modified':False}
passed=all(x.get('stopped') is True for x in services) and all(not x['listening'] for x in ports.values())
passed=passed and pg.returncode==3 and docker.returncode==0 and not docker.stdout.strip() and result['database_files_preserved']
result['status']='PASS' if passed else 'FAIL'
(out/'resource-cleanup-final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert passed
