"""Recompute observed overlap and latency from the original raw diagnostics."""
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from examples.experiment_metrics import distribution

out=Path(__file__).resolve().parent
rows=[json.loads(x) for x in (out/'benchmarks/load_raw.jsonl').read_text().splitlines()]
groups=defaultdict(list)
for row in rows:
    groups[row['concurrency']].append(row)
result=[]
for concurrency,records in sorted(groups.items()):
    peaks=[]
    for round_no in range(1,4):
        events=[]
        for row in records:
            if row['round']!=round_no:
                continue
            task=row['diagnostics']['task']
            events.extend([(datetime.fromisoformat(task['created_at']),1),(datetime.fromisoformat(task['updated_at']),-1)])
        active=peak=0
        for _,change in sorted(events):
            active+=change
            peak=max(peak,active)
        assert active==0 and peak<=concurrency
        peaks.append(peak)
    result.append({'concurrency':concurrency,'n':len(records),'succeeded':sum(r['status']=='SUCCEEDED' for r in records),
        'observed_peak_active_per_round':peaks,
        **{name:distribution([r['timings'][name] for r in records]) for name in ('queue_seconds','execution_seconds','total_seconds')}})
assert result==json.loads((out/'steady-capacity-summary.json').read_text())['groups']
print(json.dumps({'recomputed_match':True,'groups':result},indent=2))
