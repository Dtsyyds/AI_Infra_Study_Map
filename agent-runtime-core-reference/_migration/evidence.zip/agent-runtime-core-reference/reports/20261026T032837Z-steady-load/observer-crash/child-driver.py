
import asyncio, sys
from pathlib import Path
import httpx
from config.settings import settings
from examples import experiment_driver as driver
async def barrier(*args, **kwargs):
    print('ACCEPTED_AND_JOURNALED', flush=True)
    await asyncio.Event().wait()
driver.worker = barrier
async def main():
    out = Path(sys.argv[1])
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18081', trust_env=False,
            headers={'Authorization':'Bearer '+settings.user_token.get_secret_value()}) as http:
        await driver.submit_observe(http, out, {'document_id':'DOC-002','budget_ms':120000},
            {'index':0,'concurrency':1,'round':1}, record_path=out/'raw.jsonl')
asyncio.run(main())
