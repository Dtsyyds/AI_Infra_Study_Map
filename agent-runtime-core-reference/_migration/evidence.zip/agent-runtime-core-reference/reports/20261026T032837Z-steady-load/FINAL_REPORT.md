# 配额内负载、观察器恢复与当前完整回归

run：20261026T032837Z-steady-load。当前免费验证PASS；项目整体PARTIAL。真实模型未授权、独立外部验收NOT_PERFORMED、个人掌握NOT_ASSESSED。没有推送或远端CI执行。

## 本阶段完成

- 补完前轮证据加固提交b457f24及增量包，校验PASS；旧完整包未修改。
- 新增`examples.load --profile steady`：并发1/2/3，各3轮、每轮30个独立任务。默认overload配置1/5/10保持不变。源码提交d5cdfa5。
- 新增`examples.verify_load`：核对计划槽位/唯一提交和Task、事件顺序/请求身份、当前诊断终态、诊断时间推导的耗时、实际Artifact字节/hash、Worker日志与汇总重算。14项校验反例/正常路径测试；源码提交3e84262。
- 本阶段没有修改Runtime核心、配额、模型后端或案例黄金答案。新实验使前轮持久事件设计获得真实HTTP/PG证据。

## 实际执行结果

当前完整pytest：212 passed，0 failures/errors/skipped，耗时114.76秒。JUnit：`final-test-results.xml`；命令及当时完整源码hash：`commands.jsonl`中的final-pytest记录。被测源码commit为3e84262bd9c08b80b4f536ae62cefa8c37b39bb6；最终包会再次核对全部受保护代码/测试hash。Ruff通过，mypy检查84文件通过。

独立steady负载：270次唯一提交，270个SUCCEEDED、业务结果PASS；REJECTED/FAILED/TIMED_OUT/CANCELLED/NEEDS_REVIEW/OBSERVATION_ERROR均0。每个并发档位90个样本、每轮30个。脚本总历时502.16秒，含每轮等限流窗口自然到期。

| 并发 | 成功/提交 | 每轮实际活任务峰值 | 数据库受理至终态P50秒 | P95秒 | 最大秒 |
|---|---:|---|---:|---:|---:|
| 1 | 90/90 | 1/1/1 | 1.522 | 1.693 | 1.912 |
| 2 | 90/90 | 2/2/2 | 1.616 | 1.869 | 1.946 |
| 3 | 90/90 | 3/3/3 | 1.671 | 1.984 | 2.021 |

每档n=90，P95仍属小样本、不稳定。时间由DB创建/终态时间推导，包含每任务启动Worker及排队，不含轮间等待和终态后Artifact导出。客户端槽位等前一任务观察完成后才再次提交；这是本机闭环实验，不是常驻Worker生产吞吐量或性能改善证明。活任务3/每分钟30次配额未修改。

证据：`benchmarks/load_config.json`、`load_raw.jsonl`、`load_raw_events.jsonl`、`load_windows.jsonl`、`load_summary.json`；汇总文件位于`steady-capacity-summary.json`，其可重算程序为`capacity_summary.py`。

## 独立核对

`examples.verify_load`返回一致性PASS：810条事件，270个已受理Task，无未决身份，无带错误的观测。`database_load_audit.py`通过只读PG查询独立核对270个Task、270个原幂等键、270个Artifact的数据库SHA-256/字节数；其原始身份导出为`load-database-identities.json`，结果为`load-database-audit.json`。本批任务模型调用记录0，负载期间全局model_calls记录数未增加；历史Fake/预算测试记录不冒充真实调用。

原始load_raw SHA-256：`08b370a69bf8ec834a29418df6821c7b5d8ff42ffb69f3d95bb2940bb2324dd8`。
原始事件SHA-256：`04ee144c9c3af65cb0bc1bd7a0487729ebd37703e6c04e1d8a8bdf9b8998f0d5`。

真实观察进程SIGKILL探针单独执行，不计入270分母：Task `59dce725-944b-4cd3-8d38-e312fe43c233`，观察器退出码-9，杀进程前HTTP202及ACCEPTED事件已落盘、Worker尚未启动。原请求/幂等键重放仍返回同Task，数据库对应任务数1；随后新Worker在真实Docker链路执行成功，Artifact字节/hash通过。原journal不变、原raw仍不存在，不补造FINISHED；恢复结论单独存放`observer-crash/result.json`及diagnostics/Artifact。探针控制器和子进程源码一并保存。这只验证此明确屏障，不声称覆盖所有断网或崩溃时间点。

## 历史证据与当前范围

原完整基线20261026T021326Z-docker-free-validation仍独立保留：179测试、P0 A/C/F、36 Harness、25容器、4恢复点、90+50故障，原1/5/10过载270提交（108成功、162预期QUOTA_EXCEEDED）。这些独立矩阵本阶段没有重跑；本阶段重跑的是当前全部pytest、新steady负载及观察器探针。不同负载配置不混合分母，也不把270成功与旧配额拒绝比较为性能提升。

前轮证据加固20261026T031046Z-evidence-hardening有112项范围测试；它不是额外112个当前测试，当前完整回归总数为212。

新包包含当前source、当前原始reports、源码快照/命令/JUnit/交付manifest，并在history/保留上述两个历史归档的原始文件及hash。归档一致性PASS不是真实性证明或外部验收。

## 环境与清理

全程ARC_MODEL_ENABLED=false，request/token预算0；未读取模型密钥、未调用真实模型。已有Docker组资格通过sg docker子会话生效，没有改组、chmod socket或sudo。没有宿主执行候选代码。

本轮启动的API/业务服务/PG均已停止；18081/18082/55439关闭，精确项目标签下容器0，.pgdata保留。证据为`resource-cleanup.json`及相关命令日志。没有后台继续执行。

## 剩余事项

1. 独立复核当前包和history中的基线证据；按docs/interview_pack.md开展本人独立修改/故障定位练习，不由代理代签掌握。
2. 后续另获具体后端/模型/秘密变量注入方式及正预算后，先跑单个dev真实修复smoke，再独立决定72任务矩阵预算。本轮不请求追加费用。
3. 远端CI遵守不推送约定，仍NOT_RUN。

恢复入口：根目录resume.md。新实验必须新run/attempt；本轮原始证据不得覆盖。
