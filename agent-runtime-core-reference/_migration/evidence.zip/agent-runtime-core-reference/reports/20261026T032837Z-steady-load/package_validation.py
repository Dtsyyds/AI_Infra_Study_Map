"""Build a new review snapshot, retaining immutable baseline archives separately."""
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from pathlib import Path
from xml.etree import ElementTree

ROOT=Path.cwd()
REPORT=Path(__file__).resolve().parent
RUN=REPORT.name
OUTPUT=ROOT/'delivery'/RUN

def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git',*args],text=True).strip()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def copy(source,target):
    assert source.is_file() and not source.is_symlink()
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)

assert not OUTPUT.exists(), 'never overwrite delivery'
assert not git('status','--porcelain'), 'commit authorized changes before snapshot'
state=json.loads((ROOT/'TASK_STATUS.json').read_text())
assert state['run_id']==RUN and state['overall']=='PARTIAL'
assert json.loads((REPORT/'resource-cleanup.json').read_text())['status']=='PASS'
commands=[json.loads(x) for x in (REPORT/'commands.jsonl').read_text().splitlines()]
junit=f'reports/{RUN}/final-test-results.xml'
regression=next(r for r in reversed(commands) if any(junit in arg for arg in r['command']))
assert regression['exit_code']==0
source={p:sha(Path(p).read_bytes()) for p in git('ls-files').splitlines()}
protected={p for p in source if p.startswith(('core/','runtime/','api/','config/','tests/','deploy/','examples/'))
    and p not in {'examples/package_delivery.py','examples/verify_delivery.py'}}
tested=json.loads(Path(regression['source_manifest']).read_text())
assert all(tested.get(p)==source[p] for p in protected), 'code changed since regression'
OUTPUT.mkdir(parents=True)
for p in source:
    copy(ROOT/p,OUTPUT/'source'/p)
shutil.copytree(REPORT,OUTPUT/'reports'/RUN)
for name in ('FINAL_REPORT.md','environment.json','commands.jsonl'):
    copy(REPORT/name,OUTPUT/name)
for name in ('resume.md','REPRODUCE.md','blockers.md'):
    copy(ROOT/name,OUTPUT/name)
write(OUTPUT/'source_manifest.json',{'commit':git('rev-parse','HEAD'),'dirty':False,'files_sha256':source,
    'scope':'current full pytest and steady 1/2/3 load; earlier full fault/overload evidence in immutable history archives'})
write(OUTPUT/'gates.json',state)
write(OUTPUT/'tests/source_match.json',{'tested_commit':regression['commit'],'tested_source_snapshot':regression['source_manifest'],
    'runtime_and_test_files_compared':len(protected),'changed_since_test':[]})
suites=ElementTree.parse(ROOT/junit).getroot().findall('testsuite')
cases=[c for suite in suites for c in suite.findall('testcase')]
counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
counts['passed']=counts['tests']-counts['failures']-counts['errors']-counts['skipped']
assert len(cases)==counts['passed']==212 and all(not any(c.find(t) is not None for t in ('failure','error','skipped')) for c in cases)
write(OUTPUT/'tests/index.json',{'final_junit':junit,'counts':counts,'scope':'all collected tests, real PG/Docker/MCP; separate from earlier standalone fault matrices'})
referenced=set()
for p in REPORT.rglob('*'):
    if p.is_file() and p.suffix in {'.json','.jsonl','.log'}:
        referenced.update(re.findall(r'reports/process-[0-9a-f-]+\.log',p.read_text()))
for p in referenced:
    copy(ROOT/p,OUTPUT/p)
write(OUTPUT/'runs/index.json',{'directories':[f'reports/{RUN}/benchmarks',f'reports/{RUN}/observer-crash'],
    'referenced_process_logs':sorted(referenced),'missing':[]})
history=[]
for run,name in [('20261026T021326Z-docker-free-validation','acceptance_bundle'),('20261026T031046Z-evidence-hardening','incremental_bundle')]:
    prior=ROOT/'delivery'/run
    expected=(prior/(name+'.sha256')).read_text().split()[0]
    assert sha((prior/(name+'.tar.gz')).read_bytes())==expected
    for file in (name+'.tar.gz',name+'.sha256','FINAL_REPORT.md'):
        copy(prior/file,OUTPUT/'history'/run/file)
    history.append({'run_id':run,'archive':f'history/{run}/{name}.tar.gz','sha256':expected,'scope':'prior evidence, not a claim it was rerun'})
write(OUTPUT/'history/index.json',history)
(OUTPUT/'changes.patch').write_text(git('diff','b457f24782b7615f949870a23dd80f9ffaee7380','HEAD')+'\n')
write(OUTPUT/'evidence_manifest.json',{'run_id':RUN,'files_sha256':{str(p.relative_to(OUTPUT)):sha(p.read_bytes()) for p in sorted(OUTPUT.rglob('*')) if p.is_file()}})
archive=OUTPUT/'acceptance_bundle.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(OUTPUT.rglob('*')):
        if p.is_file() and p!=archive:
            assert not p.is_symlink()
            tar.add(p,arcname=RUN+'/'+str(p.relative_to(OUTPUT)),recursive=False)
checksum=sha(archive.read_bytes())
(OUTPUT/'acceptance_bundle.sha256').write_text(checksum+'  acceptance_bundle.tar.gz\n')
from examples.verify_delivery import verify
result=verify(OUTPUT)
write(OUTPUT/'bundle_validation.json',result)
print(json.dumps(result,indent=2))
