"""Read-only database reconciliation for this run's exact submission identities."""
import hashlib
import json
from collections import Counter
from pathlib import Path
import psycopg
from config.settings import settings
from examples.verify_load import verify

out=Path(__file__).resolve().parent
bench=out/'benchmarks'
result=verify(bench)
rows=[json.loads(x) for x in (bench/'load_raw.jsonl').read_text().splitlines()]
assert result['outcomes']=={'SUCCEEDED':270} and result['observations_with_errors']==0
ids=[r['task_id'] for r in rows]
expected={r['task_id']:r for r in rows}
with psycopg.connect(settings.database_url.get_secret_value()) as conn:
    tasks=conn.execute("SELECT task_id::text,session_id,status FROM arc_ref.tasks WHERE task_id=ANY(%s::uuid[])",(ids,)).fetchall()
    keys=conn.execute("SELECT task_id::text,key FROM arc_ref.idempotency_keys WHERE task_id=ANY(%s::uuid[])",(ids,)).fetchall()
    artifacts=conn.execute("SELECT task_id::text,artifact_id::text,encode(sha256(content),'hex'),octet_length(content) FROM arc_ref.artifacts WHERE task_id=ANY(%s::uuid[])",(ids,)).fetchall()
    model_calls=conn.execute("SELECT count(*) FROM arc_ref.model_calls WHERE task_id=ANY(%s::uuid[])",(ids,)).fetchone()[0]
    global_calls=conn.execute("SELECT count(*) FROM arc_ref.model_calls").fetchone()[0]
    active=conn.execute("SELECT count(*) FROM arc_ref.tasks WHERE principal_id='demo-reviewer' AND status IN ('QUEUED','RUNNING','NEEDS_REVIEW')").fetchone()[0]
assert len(tasks)==len(keys)==len(artifacts)==270
assert {t for t,s,status in tasks}==set(ids)
assert all(s==expected[t]['submission_id'] and status=='SUCCEEDED' for t,s,status in tasks)
assert dict(keys)=={t:r['submission_id'] for t,r in expected.items()}
artifact_rows={a['artifact_id']:(r['task_id'],a['sha256'],a['bytes']) for r in rows for a in r['artifacts']}
assert {a:(t,digest,size) for t,a,digest,size in artifacts}==artifact_rows
assert model_calls==active==0
assert global_calls==json.loads((out/'preflight.json').read_text())['model_call_rows_before']
assert all(r['diagnostics']['task']['result']['review_decision']=='PASS' for r in rows)
result.update(database_task_count=len(tasks),database_idempotency_key_count=len(keys),database_artifact_count=len(artifacts),
    model_calls_for_load=model_calls,global_model_call_rows_unchanged=True,active_demo_tasks_after_load=active,
    business_outcomes=dict(Counter(r['diagnostics']['task']['result']['review_decision'] for r in rows)),
    raw_sha256=hashlib.sha256((bench/'load_raw.jsonl').read_bytes()).hexdigest(),
    events_sha256=hashlib.sha256((bench/'load_raw_events.jsonl').read_bytes()).hexdigest())
(out/'load-database-audit.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'load-database-identities.json').write_text(json.dumps({'tasks':tasks,'idempotency_keys':keys,'artifacts':artifacts},indent=2)+'\n')
print(json.dumps(result,indent=2))
