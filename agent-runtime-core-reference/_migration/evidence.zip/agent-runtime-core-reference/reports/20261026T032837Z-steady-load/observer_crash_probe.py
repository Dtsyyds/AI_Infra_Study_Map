"""Trusted test controller: kill the observer after real HTTP202, before worker spawn."""
import asyncio
import hashlib
import json
import os
import signal
import sys
from pathlib import Path
import httpx
import psycopg
from config.settings import settings
from examples.demo import worker
from examples.load import wait_for_fresh_admission_window

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent / "observer-crash"
CHILD = r"""
import asyncio, sys
from pathlib import Path
import httpx
from config.settings import settings
from examples import experiment_driver as driver
async def barrier(*args, **kwargs):
    print('ACCEPTED_AND_JOURNALED', flush=True)
    await asyncio.Event().wait()
driver.worker = barrier
async def main():
    out = Path(sys.argv[1])
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18081', trust_env=False,
            headers={'Authorization':'Bearer '+settings.user_token.get_secret_value()}) as http:
        await driver.submit_observe(http, out, {'document_id':'DOC-002','budget_ms':120000},
            {'index':0,'concurrency':1,'round':1}, record_path=out/'raw.jsonl')
asyncio.run(main())
"""
def sha(content):
    return hashlib.sha256(content).hexdigest()
async def main():
    assert not OUT.exists(), 'never overwrite probe evidence'
    assert not settings.model_enabled and settings.model_request_limit == settings.model_token_limit == 0
    OUT.mkdir()
    (OUT/'child-driver.py').write_text(CHILD)
    result={'scope':'observer SIGKILL after real HTTP202, before worker start; explicit same-key reconciliation', 'status':'INCOMPLETE'}
    result['window_wait_seconds']=await wait_for_fresh_admission_window()
    env=dict(os.environ)
    env.pop('PYTHONPATH',None)
    proc=await asyncio.create_subprocess_exec(sys.executable,'-c',CHILD,str(OUT),env=env,
        stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,start_new_session=True)
    task_id=None
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18081',trust_env=False,
            headers={'Authorization':'Bearer '+settings.user_token.get_secret_value()},timeout=15) as http:
        try:
            marker=await asyncio.wait_for(proc.stdout.readline(),15)
            assert marker == b'ACCEPTED_AND_JOURNALED\n', marker
            os.killpg(proc.pid,signal.SIGKILL)
            stdout,stderr=await asyncio.wait_for(proc.communicate(),10)
            (OUT/'driver-stdout.log').write_bytes(marker+stdout)
            (OUT/'driver-stderr.log').write_bytes(stderr)
            assert proc.returncode == -signal.SIGKILL
            journal=OUT/'raw_events.jsonl'
            original=journal.read_bytes()
            events=[json.loads(line) for line in original.splitlines()]
            assert [e['event'] for e in events] == ['SUBMISSION_INTENT','ACCEPTED']
            assert not (OUT/'raw.jsonl').exists()
            intent,accepted=events
            task_id=accepted['task_id']
            key=intent['submission_id']
            before=await http.get(f'/tasks/{task_id}')
            before.raise_for_status()
            assert before.json()['status']=='QUEUED'
            replay=await http.post('/tasks',json=intent['request'],headers={'Idempotency-Key':key})
            assert replay.status_code==202 and replay.json()['task_id']==task_id
            await worker(task_id,OUT,wait_seconds=135)
            response=await http.get(f'/tasks/{task_id}/diagnostics')
            response.raise_for_status()
            diag=response.json()
            assert diag['task']['status']=='SUCCEEDED' and not diag['model_calls']
            assert diag['task']['result']['review_decision']=='PASS'
            (OUT/'diagnostics.json').write_text(json.dumps(diag,indent=2))
            artifacts=[]
            assert diag['artifacts']
            for artifact in diag['artifacts']:
                response=await http.get(f"/tasks/{task_id}/artifacts/{artifact['artifact_id']}")
                response.raise_for_status()
                content=response.content
                assert sha(content)==artifact['sha256'] and len(content)==artifact['bytes']
                path=OUT/f"artifact-{artifact['artifact_id']}.json"
                path.write_bytes(content)
                artifacts.append({**artifact,'file':str(path.relative_to(ROOT))})
            async with await psycopg.AsyncConnection.connect(settings.database_url.get_secret_value()) as conn:
                count=(await (await conn.execute("SELECT count(*) FROM arc_ref.tasks WHERE principal_id='demo-reviewer' AND session_id=%s",(key,))).fetchone())[0]
            assert count==1 and journal.read_bytes()==original and not (OUT/'raw.jsonl').exists()
            result.update(status='PASS',task_id=task_id,submission_id=key,observer_exit_code=proc.returncode,
                task_status_before_replay='QUEUED',replay_http_status=202,same_task_after_replay=True,
                persistent_task_count=count,final_runtime_status=diag['task']['status'],
                original_journal_sha256=sha(original),original_journal_unchanged=True,
                original_observation_remains_incomplete=True,model_calls=0,artifacts=artifacts)
        finally:
            if proc.returncode is None:
                os.killpg(proc.pid,signal.SIGKILL)
                await proc.communicate()
            if result['status']!='PASS':
                journal=OUT/'raw_events.jsonl'
                if journal.exists():
                    events=[json.loads(line) for line in journal.read_text().splitlines()]
                    for event in events:
                        if event['event']=='ACCEPTED':
                            await http.post(f"/tasks/{event['task_id']}/cancel")
            (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
asyncio.run(main())
