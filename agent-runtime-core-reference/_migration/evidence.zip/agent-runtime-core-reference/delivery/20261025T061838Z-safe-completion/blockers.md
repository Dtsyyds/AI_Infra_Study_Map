# 人工边界与未完成项

当前总体 PARTIAL；没有任何总体PASS或最终验收结论。缺失旧增强附件已由自包含主契约取代，不再阻塞。

| ID | 复验事实与影响 | 最小人工动作与重试 |
|---|---|---|
| B-Docker | default context=unix:///var/run/docker.sock；uid1000组不含socket gid983；socket0660 uid0；daemon访问permission denied。P0 A/C/F、12例实际Harness、容器故障矩阵BLOCKED，镜像仅配置digest未经本地检验 | 环境所有者提供已获准使用现有daemon的会话。无需扩大容器权限或给socket666，不挂socket入容器，不擅自改组。新run下执行 examples.environment / examples.p0_revalidate / pytest tests/docker |
| B-Model | 默认enabled=false、预算0、无获准模型；真实调用0。真实smoke和72任务BLOCKED，实际SDK/API兼容性/定价未知 | 明确OpenAI Responses后端与支持结构化输出的模型、可信进程秘密变量名、单请求输出token、单Task请求上限、全局请求/token硬上限及费用约束。秘密由安全环境注入，不粘贴到日志。先dev单次smoke，预算另行覆盖批量矩阵 |

权限与费用授权不互相替代。即使Docker恢复也不能自动付费调用；即使发现key也不代表预算授权。此次未尝试sudo、改权限、装daemon、prune、未知卷删除、推送或PR。

受阻验证已有实现入口：36次Harness资格、三种修复恢复、5类容器各5次、72/270独立实验及完整阶段统计。它们尚未实际执行，真实环境可能揭示待修问题。PG锁等待与非容器SIGTERM已实测，不能替代满负载容量和容器停止证明。远端CI因不推送而NOT_RUN；生产可靠性未验收。详见docs/remaining_user_actions.md；没有后台续跑。

最终Artifact缺项：标准审核最终报告与真实修复DELIVERED patch均MISSING（根因Docker及模型阻塞）；已有NOT_RUN基线和合成存储patch Artifact用途明确，不能替代它们。外部最终验收NOT_PERFORMED；个人掌握NOT_ASSESSED。
