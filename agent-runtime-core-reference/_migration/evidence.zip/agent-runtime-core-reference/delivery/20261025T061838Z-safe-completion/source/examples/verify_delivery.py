"""Read-only archive verification. Integrity PASS is never project acceptance."""

import argparse
import hashlib
import json
import tarfile
from pathlib import Path, PurePosixPath
from xml.etree import ElementTree


def verify(directory):
    archive = directory / "acceptance_bundle.tar.gz"
    checksum = (directory / "acceptance_bundle.sha256").read_text().split()[0]
    if hashlib.sha256(archive.read_bytes()).hexdigest() != checksum:
        raise ValueError("ARCHIVE_HASH_MISMATCH")
    prefix = directory.name + "/"
    with tarfile.open(archive, "r:gz") as tar:
        members = tar.getmembers()
        names = [m.name for m in members]
        if len(names) != len(set(names)):
            raise ValueError("DUPLICATE_ARCHIVE_MEMBER")
        for member in members:
            path = PurePosixPath(member.name)
            if (
                not member.isfile()
                or path.is_absolute()
                or ".." in path.parts
                or not member.name.startswith(prefix)
            ):
                raise ValueError("UNSAFE_ARCHIVE_MEMBER")
            if {".env", ".git", ".pgdata", ".venv", ".postgres", ".python"} & set(path.parts):
                raise ValueError("EXCLUDED_ENVIRONMENT_INCLUDED")

        def content(name):
            stream = tar.extractfile(prefix + name)
            if stream is None:
                raise ValueError("MISSING_ARCHIVE_FILE")
            return stream.read()

        manifest = json.loads(content("evidence_manifest.json"))
        for name, expected in manifest["files_sha256"].items():
            if hashlib.sha256(content(name)).hexdigest() != expected:
                raise ValueError("EVIDENCE_HASH_MISMATCH: " + name)
        tests = json.loads(content("tests/index.json"))
        suite = ElementTree.fromstring(content(tests["final_junit"]))
        counts = {
            key: sum(int(s.attrib.get(key, 0)) for s in suite.findall("testsuite"))
            for key in ("tests", "errors", "failures", "skipped")
        }
        counts["passed"] = (
            counts["tests"] - counts["errors"] - counts["failures"] - counts["skipped"]
        )
        if counts != tests["counts"]:
            raise ValueError("TEST_TOTAL_MISMATCH")
        source = json.loads(content("source_manifest.json"))
        for path, expected in source["files_sha256"].items():
            if hashlib.sha256(content("source/" + path)).hexdigest() != expected:
                raise ValueError("SOURCE_HASH_MISMATCH")
        if json.loads(content("tests/source_match.json"))["changed_since_test"]:
            raise ValueError("SOURCE_CHANGED_SINCE_TEST")
        if json.loads(content("runs/index.json"))["missing"]:
            raise ValueError("REFERENCED_LOG_MISSING")
        gates = json.loads(content("gates.json"))
        if gates["overall"] == "PASS" and (
            gates["p0"] != "PASS" or counts["skipped"] or counts["errors"] or counts["failures"]
        ):
            raise ValueError("FALSE_OVERALL_PASS")
    return {
        "integrity_status": "PASS",
        "scope": "hashes, counts, references and source consistency only",
        "source_commit": source["commit"],
        "archive_sha256": checksum,
        "verified_files": len(manifest["files_sha256"]),
        "test_counts": counts,
        "project_status": gates["overall"],
        "external_acceptance": gates["external_acceptance"],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    result = verify(args.directory)
    (args.directory / "bundle_validation.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
