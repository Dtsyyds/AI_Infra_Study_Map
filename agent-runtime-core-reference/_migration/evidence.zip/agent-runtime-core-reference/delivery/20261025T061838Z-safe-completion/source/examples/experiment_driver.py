"""Trusted HTTP experiment driver. Each attempted submission yields a record even on failure."""

import json
import time
from pathlib import Path
from uuid import uuid4

import httpx

from examples.demo import worker
from examples.experiment_metrics import model_accounting, task_timings


def append_record(path: Path, record: dict):
    with path.open("a") as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + "\n")
        stream.flush()


async def submit_observe(client, out, body, slot, *, model=False):
    identifier = str(uuid4())
    tick = time.monotonic()
    record = {
        **slot,
        "submission_id": identifier,
        "task_id": None,
        "status": "OBSERVATION_ERROR",
        "http_status": None,
        "timings": {},
        "errors": [],
    }
    try:
        response = await client.post(
            "/tasks",
            headers={"Idempotency-Key": identifier},
            json={**body, "session_id": identifier},
        )
        record["http_status"] = response.status_code
        if response.status_code != 202:
            record.update(
                status="REJECTED"
                if response.status_code in {400, 401, 403, 409, 413, 422, 429, 503}
                else "HTTP_ERROR",
                rejection=response.json(),
            )
            return record
        task_id = response.json()["task_id"]
        record["task_id"] = task_id
        try:
            await worker(task_id, out, wait_seconds=135)
        except (TimeoutError, AssertionError, OSError) as exc:
            record["errors"].append(type(exc).__name__)
        response = await client.get(f"/tasks/{task_id}/diagnostics")
        response.raise_for_status()
        diag = response.json()
        record.update(status=diag["task"]["status"], runtime_status=diag["task"]["status"], diagnostics=diag, timings=task_timings(diag))
        if model:
            record["model_accounting"] = model_accounting(diag)
        # Export every actual BYTEA artifact; require metadata equality.
        import hashlib

        artifacts = []
        for artifact in diag.get("artifacts", []):
            response = await client.get(f"/tasks/{task_id}/artifacts/{artifact['artifact_id']}")
            response.raise_for_status()
            content = response.content
            digest = hashlib.sha256(content).hexdigest()
            if digest != artifact["sha256"] or len(content) != artifact["bytes"]:
                raise ValueError("ARTIFACT_MISMATCH")
            path = out / f"artifact-{artifact['artifact_id']}.json"
            path.write_bytes(content)
            artifacts.append({**artifact, "file": str(path)})
        record["artifacts"] = artifacts
    except (httpx.HTTPError, ValueError, KeyError, OSError) as exc:
        record["errors"].append(type(exc).__name__)
        record["observation_incomplete"] = True
        record["status"] = "OBSERVATION_ERROR"
        if "model_accounting" in record:
            record["model_accounting"]["delivered"] = False
            record["model_accounting"]["errors"].append("OBSERVATION_INCOMPLETE")
    finally:
        record["submission_wall_seconds"] = time.monotonic() - tick
    return record
