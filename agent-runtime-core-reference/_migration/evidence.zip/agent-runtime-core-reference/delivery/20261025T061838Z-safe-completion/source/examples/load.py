"""270 unique submissions, explicit overload classifications; no 202-as-success shortcut."""

import argparse
import asyncio
import json
from pathlib import Path

import httpx

from config.settings import settings
from examples.experiment_driver import append_record, submit_observe
from examples.experiment_metrics import summarize_experiment
from runtime.tools.docker_backend import DockerBackend


async def run(execute):
    state = json.loads(await asyncio.to_thread(Path("TASK_STATUS.json").read_text))
    out = Path("reports") / state["run_id"] / "benchmarks"
    out.mkdir(parents=True, exist_ok=True)
    plan = {
        "kind": "deterministic_document_review_runtime",
        "concurrency": [1, 5, 10],
        "rounds": 3,
        "submissions_per_round": 30,
        "total": 270,
        "planner": "deterministic",
        "admission_limit_per_principal": 3,
        "rate_limit_per_minute": 30,
        "note": "overload refusals are counted separately, never mixed into successful latency",
    }
    available = await DockerBackend().availability()
    if not execute or not available["available"]:
        plan.update(
            status="BLOCKED" if not available["available"] else "NOT_RUN", actual_submissions=0
        )
        (out / "load_not_run.json").write_text(json.dumps(plan, indent=2))
        print(json.dumps(plan))
        return
    (out / "load_config.json").write_text(json.dumps(plan, indent=2))
    raw = out / "load_raw.jsonl"
    if raw.exists():
        raise RuntimeError("choose new run_id; no evidence overwrite")
    async with httpx.AsyncClient(
        base_url="http://127.0.0.1:18081",
        trust_env=False,
        headers={"Authorization": "Bearer " + settings.user_token.get_secret_value()},
        timeout=10,
    ) as client:
        for concurrency in (1, 5, 10):
            for repeat in range(1, 4):
                semaphore = asyncio.Semaphore(concurrency)

                async def task(index, semaphore=semaphore, concurrency=concurrency, repeat=repeat):
                    async with semaphore:
                        result = await submit_observe(
                            client,
                            out,
                            {"document_id": "DOC-002", "budget_ms": 120000},
                            {"index": index, "concurrency": concurrency, "round": repeat},
                        )
                        append_record(raw, result)

                await asyncio.gather(*(task(i) for i in range(30)))
    rows = [json.loads(line) for line in raw.read_text().splitlines()]
    (out / "load_summary.json").write_text(
        json.dumps(summarize_experiment(rows, kind="load", planned=270), indent=2)
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    asyncio.run(run(parser.parse_args().execute))
