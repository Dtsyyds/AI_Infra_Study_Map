import httpx

from examples.experiment_driver import submit_observe


async def test_202_without_terminal_evidence_is_not_success(tmp_path, monkeypatch):
    async def no_worker(*args, **kwargs):
        pass
    monkeypatch.setattr("examples.experiment_driver.worker", no_worker)
    def handler(request):
        if request.method == "POST":
            return httpx.Response(202, json={"task_id": "task"})
        return httpx.Response(503, json={"error": "DB_BUSY"})
    async with httpx.AsyncClient(base_url="http://local", transport=httpx.MockTransport(handler)) as client:
        result = await submit_observe(client, tmp_path, {}, {"index": 0})
    assert result["http_status"] == 202 and result["status"] == "OBSERVATION_ERROR"
    assert result["task_id"] == "task" and result["observation_incomplete"]


async def test_submission_failure_still_has_unique_identity_and_raw_error(tmp_path):
    def handler(request):
        raise httpx.ConnectError("synthetic")
    async with httpx.AsyncClient(base_url="http://local", transport=httpx.MockTransport(handler)) as client:
        one = await submit_observe(client, tmp_path, {}, {})
        two = await submit_observe(client, tmp_path, {}, {})
    assert one["submission_id"] != two["submission_id"]
    assert one["status"] == "OBSERVATION_ERROR" and one["errors"] == ["ConnectError"]
