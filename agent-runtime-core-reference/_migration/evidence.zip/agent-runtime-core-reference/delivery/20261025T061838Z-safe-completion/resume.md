# 恢复入口

本轮run_id：20261025T061838Z-safe-completion；总体PARTIAL，P0 BLOCKED。实现被测提交5b0f521aeae028aaa3c590d1e86ec8111550af29，最终文档提交由delivery内source_manifest.json记录。旧验收包保持不变。

最终151 passed、22 skipped（Docker权限）；Ruff及83文件mypy通过。90+50条故障探针已复跑，严格区分局部通过与复合BLOCKED。源码、报告、原始数据、Artifact、命令和退出码集中于新delivery验收包；详见reports/20261025T061838Z-safe-completion/FINAL_REPORT.md。

API/业务服务/PG均已停止，端口18081/18082/55439不监听；.pgdata保留。无后台继续或自动下一会话执行。

## 下一次执行顺序

1. 先完整阅读CODEX_MASTER_PLAN.md及本文件，核对Git状态、TASK_STATUS.json与新包，不用历史PASS推断当前环境。
2. 按docs/remaining_user_actions.md取得已获准Docker会话。先只读复验docker version/context/socket，不自行提权。创建新run并保留本轮不可变报告。
3. 在项目范围启动PG/服务、核验固定镜像，复跑P0 A/C/F，再跑examples.harness_acceptance的36次独立资格；保留失败并修复实际发现问题。
4. 跑examples.repair_recovery三场景、examples.sandbox_matrix五类各5次及270确定性负载。入口/参数见REPRODUCE.md；禁止宿主执行候选。
5. 仅在另有明确后端/模型/秘密注入及预算授权时进行单个dev真实smoke；没有授权保持BLOCKED且不回退Fake。72模型任务另需足额预算，4dev/8holdout，禁止给模型黄金patch。
6. 重新计算模型/负载独立统计，全部原始证据进入新包，自测后交ChatGPT独立验收。真实环境失败可能需要进一步实现修复，未保证未执行分支必过。

仅需你提供Docker环境与模型授权信息，不需手工修代码或逐切片批准。外部验收NOT_PERFORMED，个人掌握NOT_ASSESSED，正式学习工程及month目录未修改。
