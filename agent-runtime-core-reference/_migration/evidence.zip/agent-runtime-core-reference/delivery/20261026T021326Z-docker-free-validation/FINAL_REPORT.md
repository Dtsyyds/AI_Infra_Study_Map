# 免费验证与必要修复交付

run_id：20261026T021326Z-docker-free-validation。本次用户要求范围内的免费验证PASS；项目总体PARTIAL，真实模型未授权且未调用，外部验收NOT_PERFORMED，个人掌握NOT_ASSESSED。

最终全量回归被测提交：3d1a915f1c005d9980c31f33bc68e3059be8db7e。打包时源码和文档提交由source_manifest.json记录。全部命令、源码快照、起止时间和退出码见commands.jsonl；早期权限/恢复失败保留于reports/20261026T020248Z-no-paid-validation并纳入补充证据。哈希只能证明一致性，不能替代独立验收。

## 完成的验证

- 全量pytest：179 passed、0 skipped、0 failures/errors；Ruff通过，mypy通过83个源码文件。
- P0 A/C/F全部PASS：正常审核最终报告、步骤提交后独立Worker恢复、真实运行容器超时终止/清理。C的真实MCP读取为首次1、接替0，已完成步骤未重放。
- 12例×基线/正确人工补丁/错误补丁=36次独立Harness资格验证通过；原始缺陷按预期FAIL、人工参考修复PASS、错误补丁FAIL。gold资产仅供可信资格校验器使用，未交给模型生成候选；人工参考修复与模型结果严格分开。
- 对36份真实inspect记录复核：用户65534:65534、network=none、read-only root、cap-drop ALL、no-new-privileges、CPU0.5、内存128MiB、PID32，无宿主bind挂载。隔离不是任意恶意Python的强安全证明。
- 三个原定修复恢复点全部PASS；增加活容器SIGTERM退出→确认ABSENT→独立Worker恢复也PASS。强杀恢复保留旧验证run、新物理run及相同逻辑tool_call，候选身份/计数不重置。
- 容器正常、超时、内存耗尽、取消、强杀恢复各5次，共25/25 PASS；OOM证据来自实际容器状态。
- reliability 90/90、additional-faults 50/50限定范围通过；其中受理后未认领恢复的10次最终报告也PASS。显式不变量违规0。合成完成/摘要探针不冒充真实模型效果。
- PG锁等待/连接池、0001→head→head自有临时库迁移、SQL计划、HTTP CLI/Artifact均通过。live和ready均200。迁移探针自有临时库已删除，SQL合成数据事务回滚。
- 确定性负载270/270条唯一提交，结果：SUCCEEDED 108、REJECTED 162。拒绝原因：QUOTA_EXCEEDED 162。统计重算与原始汇总一致。模型任务0，未创建假的model_raw。`evaluate`日志中的load=0仅表示模型驱动器自身不执行负载；项目负载数量以独立load-attempt-2记录为准。

## 实际修复

1. 系统已授予dts Docker组资格，但Codex执行进程继承旧组。经工具批准用sg docker启用已有组权限，无用户组/socket权限修改、无sudo。固定镜像已拉取并核验digest。
2. 真实恢复探针曾使用随机未授权principal而失败为TOOL_FORBIDDEN；改为既有demo-reviewer和唯一Task/Session，保持原策略。
3. SDK导入预设ERROR日志抑制清理证据；Worker CLI显式配置INFO，独立子进程反例覆盖。
4. 跨组/proc权限不足曾被服务脚本误判停止并覆盖PID记录；改为UNKNOWN、保留记录和拒绝继续，补反例测试。
5. 环境报告实际核验镜像，打包器收集当前审核Artifact并区分Fake证据；不再硬编码Docker阻塞。
6. 负载每轮等待既有限流窗口自然到期，等待单独记录，不重置配额、不计入任务耗时。
7. 首次负载实际任务成功，但诊断API缺少Artifact sha256，驱动器记录78条OBSERVATION_ERROR；另有1个被中断任务单独保留诊断。补充数据库侧sha256元数据及匹配/错配回归后，用load-attempt-2重新执行270次，不覆盖或混合失败数据。

## 负载分母与局限

| 并发 | 轮次 | 30次提交的结果 |
|---|---|---|
| 1 | 1 | SUCCEEDED=30 |
| 1 | 2 | SUCCEEDED=30 |
| 1 | 3 | SUCCEEDED=30 |
| 5 | 1 | REJECTED=27、SUCCEEDED=3 |
| 5 | 2 | REJECTED=27、SUCCEEDED=3 |
| 5 | 3 | REJECTED=27、SUCCEEDED=3 |
| 10 | 1 | REJECTED=27、SUCCEEDED=3 |
| 10 | 2 | REJECTED=27、SUCCEEDED=3 |
| 10 | 3 | REJECTED=27、SUCCEEDED=3 |

每轮n/N、按终态分组的队列/执行/总耗时P50/P95/最大值见benchmarks/load-attempt-2/load_summary.json及load_summary-recomputed.json。每principal活动配额仍为3；并发5/10含预期过载拒绝，不能称270次任务全部成功，更不能用拒绝耗时宣传吞吐或P95提升。样本小，未与同条件旧实现对比，不作生产容量结论。

## Task与Artifact

P0完整关联与3份审核报告字节/hash见p0/results.json和artifacts/index.json。A任务：f74e9fed-157b-4d5c-93c3-e72bc015dca9, e698194e-1d23-4685-9c74-d156427904dd；C任务：80c04b0e-b716-4c9c-a60d-a6d801f4e4a2；F任务：07c65b2f-8b19-4d24-9e69-d41eca4242b0。

repair-demo使用确定性Fake，Runtime SUCCEEDED、业务UNRESOLVED，实际产生3候选并在容器得到失败反馈，证明有界控制流而非成功修复。人工正确patch的PASS只用于独立Harness资格，不归为模型结果。repair-process显式合成fixture仅证明存储恢复，与真实repair-recovery记录分开。

## 剩余边界与资源

G0/G1/G2/G4免费验证通过；G5本地等价验证通过、远端CI未推送所以NOT_RUN；G3真实模型和G6模型实验按用户指令未授权。模型开关false、请求/token预算0、真实模型请求0。外部独立验收和个人掌握不能由本会话代签。

自有API、业务服务、PostgreSQL已停止；18081/18082/55439均不监听；Docker项目标签检查成功且剩余容器0，数据库文件保留。详见resource-cleanup.json。未做全局prune、未知卷删除、推送/PR、宿主候选执行，未读取/修改正式学习工程或month目录。

## 复核入口

REPRODUCE.md提供有效组会话与免费验证入口。validation-audit.json及audit_results.py复核计数、状态、真实隔离参数、Artifact哈希与统计；examples.verify_delivery只核对包完整性。交付路径delivery/20261026T021326Z-docker-free-validation/acceptance_bundle.tar.gz；旧验收包保持不变。后续从resume.md进入；没有后台自动继续。
