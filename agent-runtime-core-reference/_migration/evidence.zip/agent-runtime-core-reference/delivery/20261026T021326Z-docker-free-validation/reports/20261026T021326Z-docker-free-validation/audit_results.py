"""Cross-check recorded evidence without executing any candidate or contacting a model."""
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree

sys.path.insert(0, str(Path.cwd() / 'source' if (Path.cwd() / 'source').is_dir() else Path.cwd()))
from examples.experiment_metrics import summarize_experiment
from examples.harness_acceptance import qualified

out = Path(__file__).resolve().parent

def read(name):
    return json.loads((out/name).read_text())

def rows(name):
    return [json.loads(line) for line in (out/name).read_text().splitlines()]

suite = ElementTree.parse(out/'final-test-results-2.xml').getroot().findall('testsuite')
counts = {key:sum(int(s.get(key,0)) for s in suite) for key in ('tests','failures','errors','skipped')}
assert counts['tests'] == 179 and not any(counts[key] for key in ('failures','errors','skipped'))
assert read('environment.json')['docker']['local_image_verified']
assert qualified(out/'harness-acceptance')
harness = rows('harness-acceptance/results.jsonl')
for row in harness:
    host = row['result']['container_evidence']['container']['HostConfig']
    config = row['result']['container_evidence']['container']['Config']
    assert host['NetworkMode'] == 'none' and host['ReadonlyRootfs'] and not host['Privileged']
    assert config['User'] == '65534:65534' and host['CapDrop'] == ['ALL']
    assert 'no-new-privileges' in ' '.join(host['SecurityOpt'])
    assert host['Memory'] == 134217728 and host['PidsLimit'] == 32 and host['NanoCpus'] == 500000000
    assert not host['Binds']

p0=read('p0/results.json');assert p0['overall']=='PASS'
assert p0['C']['real_read_counts']=={'first_worker':1,'replacement_worker':0}
document_artifacts=[]
for task in p0['identities']:
    for artifact in task['artifacts']:
        data=(out/'p0'/artifact['file']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==artifact['sha256'] and len(data)==artifact['bytes']
        document_artifacts.append({'task_id':task['task_id'],**artifact})
assert len(document_artifacts)==3
recovery=rows('repair-recovery/results.jsonl');assert len(recovery)==4 and all(x['status']=='PASS' for x in recovery)
assert {x['point'] for x in recovery}=={'patch_committed','verification_committed','test_running','graceful_stop'}
matrix=rows('sandbox-matrix/results.jsonl');assert len(matrix)==25 and all(x['executed'] and x['status']=='PASS' for x in matrix)
assert Counter(x['kind'] for x in matrix)==dict.fromkeys(['normal','timeout','memory','cancel','process_kill_recovery'],5)
faults=rows('reliability/raw.jsonl');additional=rows('additional-faults/raw.jsonl')
assert len(faults)==90 and len(additional)==50
assert all(x['result']['status']=='passed' for x in faults)
assert all(value is not False for x in faults for value in x['result'].get('invariants',{}).values())
assert all(x['status']=='passed' for x in additional)
assert all(x.get('full_report','PASS')=='PASS' for x in additional)
load=rows('benchmarks/load-attempt-2/load_raw.jsonl');assert len(load)==270
assert Counter((x['concurrency'],x['round']) for x in load)=={(c,r):30 for c in (1,5,10) for r in (1,2,3)}
computed=summarize_experiment(load,kind='load',planned=270)
assert computed==read('benchmarks/load-attempt-2/load_summary.json')==read('benchmarks/load-attempt-2/load_summary-recomputed.json')
assert not any(x['status'] in {'FAILED','TIMED_OUT','NEEDS_REVIEW','RUNNING','QUEUED','OBSERVATION_ERROR','HTTP_ERROR'} for x in load)
for x in load:
    if x['status']=='REJECTED':
        assert x['http_status']==429 and x['rejection']['error'] in {'QUOTA_EXCEEDED','RATE_LIMITED'}
    else:
        assert x['status']=='SUCCEEDED' and x['diagnostics']['model_calls']==[] and x['artifacts']
    for artifact in x.get('artifacts',[]):
        data=Path(artifact['file']).read_bytes()
        assert len(data)==artifact['bytes'] and hashlib.sha256(data).hexdigest()==artifact['sha256']

demo=read('repair-demo/result.json');assert demo['runtime_status']=='SUCCEEDED' and demo['business_outcome']=='UNRESOLVED'
assert len(demo['candidate_numbers'])==3 and demo['real_model_calls']==0
model=read('benchmarks/not_run.json');assert model['model_observed_tasks']==0 and model['model_requests_limit']==model['model_tokens_limit']==0
assert not (out/'benchmarks/model_raw.jsonl').exists()
result={
    'status':'PASS', 'scope':'self-audit of free validation evidence, not external acceptance',
    'tests':counts,'harness_runs':len(harness),'inspected_isolation_records':len(harness),
    'p0':p0['overall'],'document_artifacts':document_artifacts,
    'repair_recovery_points':[x['point'] for x in recovery],'sandbox_runs':len(matrix),
    'fault_records':len(faults),'additional_records':len(additional),'invariant_violations':0,
    'load_submissions':len(load),'load_outcomes':dict(Counter(x['status'] for x in load)),
    'load_rejections':dict(Counter(x['rejection']['error'] for x in load if x['status']=='REJECTED')),
    'repair_demo_outcome':demo['business_outcome'],'real_model_calls':0,
}
(out/'validation-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
