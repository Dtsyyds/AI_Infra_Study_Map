set -eu
cd /home/dts/agent-runtime-core-reference
export ARC_MODEL_ENABLED=false ARC_MODEL_REQUEST_LIMIT=0 ARC_MODEL_TOKEN_LIMIT=0
unset PYTHONPATH
record() {
  name=$1
  shift
  .venv/bin/python -m examples.evidence --name "$name" -- "$@"
}
record ruff .venv/bin/ruff check core runtime api config tests examples deploy
record mypy .venv/bin/mypy
record pytest .venv/bin/python -m pytest -q -rs --junitxml=reports/20261026T021326Z-docker-free-validation/final-test-results.xml
record reliability .venv/bin/python -m examples.reliability
record additional-faults .venv/bin/python -m examples.additional_faults
record load .venv/bin/python -m examples.load --execute
record model-not-authorized .venv/bin/python -m examples.evaluate
record summarize-reliability .venv/bin/python -m examples.summarize reports/20261026T021326Z-docker-free-validation/reliability/raw.jsonl reports/20261026T021326Z-docker-free-validation/reliability/summary.json
record summarize-additional .venv/bin/python -m examples.summarize reports/20261026T021326Z-docker-free-validation/additional-faults/raw.jsonl reports/20261026T021326Z-docker-free-validation/additional-faults/summary.json
record load-recompute .venv/bin/python -m examples.experiment_metrics load reports/20261026T021326Z-docker-free-validation/benchmarks/load_raw.jsonl reports/20261026T021326Z-docker-free-validation/benchmarks/load_summary-recomputed.json
