set -eu
cd /home/dts/agent-runtime-core-reference
export ARC_MODEL_ENABLED=false ARC_MODEL_REQUEST_LIMIT=0 ARC_MODEL_TOKEN_LIMIT=0
unset PYTHONPATH
record() {
  name=$1
  shift
  .venv/bin/python -m examples.evidence --name "$name" -- "$@"
}
record services-stop .venv/bin/python -m examples.services stop
record services-start .venv/bin/python -m examples.services start
record environment .venv/bin/python -m examples.environment
record lifecycle-retest .venv/bin/python -m pytest tests/docker/test_lifecycle_matrix.py -q -x -rs
for probe in p0_revalidate harness_acceptance repair_recovery sandbox_matrix backend_probe migration_probe sql_probe repair_demo repair_process_probe cli_probe; do
  record "$probe" .venv/bin/python -m "examples.$probe"
done
