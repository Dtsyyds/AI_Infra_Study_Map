"""Read-only final resource evidence; run after stopping this session's services."""
import json
import os
import socket
import subprocess
import tempfile
from datetime import UTC, datetime
from pathlib import Path

root = Path.cwd()
ports = {}
for port in (18081, 18082, 55439):
    with socket.socket() as client:
        client.settimeout(2)
        code = client.connect_ex(('127.0.0.1', port))
        ports[str(port)] = {'connect_errno': code, 'listening': code == 0}
        assert code in (0, 111), 'unexpected network error; cannot claim resource stopped'
pg = subprocess.run([str(root / '.postgres/bin/pg_ctl'), '-D', str(root / '.pgdata'), 'status'], capture_output=True, text=True)
with tempfile.TemporaryDirectory(prefix='arc-ref-resource-') as cfg:
    docker = subprocess.run(['docker', '--config', cfg, 'ps', '--all', '--quiet', '--filter', 'label=io.agent-runtime-core-reference.project=reference'], env={'PATH': os.defpath, 'DOCKER_HOST': 'unix:///var/run/docker.sock'}, capture_output=True, text=True, timeout=15)
services = json.loads((root/'reports/services.json').read_text())
result = {
    'observed_at': datetime.now(UTC).isoformat(),
    'services': services, 'ports': ports,
    'postgres_status_exit_code': pg.returncode,
    'postgres_status_stdout': pg.stdout, 'postgres_status_stderr': pg.stderr,
    'database_files_preserved': (root/'.pgdata/PG_VERSION').is_file(),
    'docker_project_inspection': {'exit_code': docker.returncode, 'remaining_container_ids': docker.stdout.splitlines(), 'stderr': docker.stderr, 'scope': 'only project label; no global prune or deletion'},
    'unrelated_resources_modified': False,
}
result['status'] = 'PASS' if all(s['stopped'] is True for s in services) and all(not v['listening'] for v in ports.values()) and pg.returncode == 3 and docker.returncode == 0 and not docker.stdout.strip() else 'FAIL'
Path(__file__).with_name('resource-cleanup.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['status'] == 'PASS'
