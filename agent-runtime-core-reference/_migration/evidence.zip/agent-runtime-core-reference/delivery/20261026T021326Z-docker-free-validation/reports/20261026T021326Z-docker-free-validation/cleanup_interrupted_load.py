import asyncio
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from config.settings import settings
from examples.process_scenarios import _wait_expired
from runtime.storage.pool import close_pools
from runtime.storage.store import Store
from runtime.tools.docker_backend import DockerBackend

async def main():
    out=Path(__file__).resolve().parent
    metadata=json.loads((out/'benchmarks/interrupted-attempt.json').read_text())
    store=Store(settings.database_url.get_secret_value());records=[]
    try:
        for task_id in metadata['worker_tasks_without_final_record']:
            before=await store.diagnostics(task_id)
            if before['task']['status'] in {'QUEUED','RUNNING'}:
                await store.cancel(task_id,before['task']['principal_id'])
                if before['task']['status']=='RUNNING':
                    await _wait_expired(store,task_id)
                await store.claim('interrupted-load-cleanup',3,task_id)
            after=await store.diagnostics(task_id)
            assert after['task']['status'] not in {'RUNNING','QUEUED'}
            records.append({'task_id':task_id,'submission_id':before['task']['request']['session_id'],'before':before,'after':after})
        backend=DockerBackend()
        removed=await backend.cleanup_orphans(store.attempt_active)
        (out/'benchmarks/interrupted-task-diagnostics.json').write_text(json.dumps({'scope':'separate interruption evidence, not added to a successful load denominator','tasks':records,'removed_owned_expired_containers':removed},indent=2))
        print(json.dumps({'tasks':len(records),'statuses':[r['after']['task']['status'] for r in records],'removed':removed}))
    finally:
        await close_pools()
asyncio.run(main())
