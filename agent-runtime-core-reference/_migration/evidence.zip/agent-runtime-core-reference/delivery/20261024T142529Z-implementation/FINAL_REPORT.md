# 实施自测报告：PARTIAL / BLOCKED

run_id：20261024T142529Z-implementation。对象仅为独立 agent-runtime-core-reference。主契约 CODEX_MASTER_PLAN.md job-delivery-v2。**不是最终验收通过声明**；外部复核 NOT_PERFORMED，个人掌握 NOT_ASSESSED。

## 交付实物与版本

本轮已修改源码并小步本地提交：严格 CaseManifest/独立 Verdict、受控 Patch/stdlib runner、12 个原创合成案例、Python AST 上下文、显式 Fake/真实 Responses Adapter、持久候选/验证/模型预算、最多三候选控制器、现有六层集成、Docker UNKNOWN 清理修复、连接池/API 限额/health、HTTP CLI、迁移/SQL/故障/实验入口及验收包工具。没有推送/PR，无正式学习工程或 month 源码读取/复制/修改。

本地基线 6fd49a8；全量回归对应 ae3db9c1e020af2b32a16dd732ed91c9ea3ca6e6。打包的最终完整 commit、源码逐文件 hash、dirty 状态见 source_manifest.json（包含后续文档及打包工具）；每条录制命令另有执行时源码快照。旧报告原样保留在 history，不用于本轮计数；不能拼接历史 Task ID 当当前全链路。

## 各门事实

| 门 | 已实现及实际验证 | 未关闭原因 |
|---|---|---|
| G0 | 重跑历史17单元；修复inspect UNKNOWN；本轮A/C/F原始报告；真实MCP/Worker恢复 | Docker权限阻塞；A/C无最终审核Artifact，F无实际启动/终止证据 |
| G1 | Manifest、独立judge及篡改/旧PASS/空测试等数据反例；当前PG提交重算 | 12例真实基线/人工正确patch尚未容器验证 |
| G2 | 固定镜像/argv、路径/尺寸限制、基准+patch重建、Docker执行后端 | 容器实际运行/资源/取消/清理未验证；不能用Mock替代 |
| G3 | AST静态引用与受限上下文；Fake和真实Adapter分开；持久请求/token预算；录制契约 | 真实provider/model/凭据与正预算未授权，真实调用0；兼容性未实测 |
| G4 | PostgreSQL候选/验证/预算事务；取消/旧Attempt/旧PASS拒绝；独立进程patch提交后恢复 | 该恢复用合成存储fixture；测试运行中与结果提交后退出待真实沙箱 |
| G5 | 真实HTTP CLI全部命令、health503、输入/连接上限、空库/升级/重复迁移、SQL计划、本地静态/类型/测试 | 无远端CI；未验证生产容量、完整锁等待指标与活容器优雅退出 |
| G6 | 12题4dev/8holdout预分组；两类实验入口；90+50条故障原始记录及统计 | 72真实模型/270负载均0；容器5类×5次尚未运行；完整分阶段延迟待补 |
| G7 | 源码、命令/原始数据、hash、岗位映射、威胁模型、复现与恢复说明、归档 | 本报告只提交可复核包；主链路阻塞，不代外部评审宣布验收 |

## 测试与实验的准确分母

最终 `final-test-results.xml`：**132 passed、14 skipped、0 failed、0 errors**，实际35.76秒；14 skipped均为Docker权限BLOCKED（两项原Docker、12例Harness）。过程中的初始Mock失误和mypy失败日志完整保留，最终回归及静态检查已通过。Ruff通过；mypy最终检查76源码文件通过。pytest中的进程恢复测试只断言明确局部不变量，不代表完整业务通过。

`reliability/raw.jsonl` 90条：外部幂等/可查询/不安全各10、旧Worker30、checkpoint10、取消顺序10（每条含取消先与完成先）、审计/安全10。70条局部passed；checkpoint与安全复合场景20条blocked，分别缺Docker最终报告/容器超时。它们仍保存实际MCP1→0、审计拒派发等局部证据。外部效果计数来自独立 arc_business 表，不只用Ledger自报；这些是局部publish故障探针。

`additional-faults/raw.jsonl` 50条：受理未认领退出10、自由取消/完成竞争30、错误摘要5类×2。均通过限定不变量；受理恢复的最终审核仍BLOCKED。自由竞争以同起点事件并发两条PG事务，不用sleep选择结果；错误摘要是纯数据契约测试，不算运行中模型行为。

SQL计划使用1000条事务内临时合成数据，已回滚，未宣称优化提升。迁移探针只创建/删除自己随机命名的新库，0001→head→head均退出0、removed=true。API/CLI实测提交/取消/等待/诊断/Artifact读取；ready为503（PG可用，Docker不可用）。

72模型任务与270确定性负载：**实际均0**。独立 not_run 清单记录计划配置与阻塞，没有假造 raw 执行样本。140条故障记录不是270负载，也不是模型修复成绩。故障P50/P95是探针墙钟（小样本不稳定），不能宣传任务执行延迟或性能改善。

## 关键 Task 与 Artifact

- P0 A：DOC-001 `70fbe9b5-e3b1-44fa-8e62-84b06d5f20ae`，DOC-002 `47967af1-2ee0-478c-8c35-326d320b6eb1`；均 FAILED/DOCKER_UNAVAILABLE，checkpoint0。最终报告 MISSING；实际MCP计数0来自缓存命中，不宣称冷读取。
- P0 C：`a75e971c-e713-444e-aa52-6d6cfa4d2b1f`，独立Worker恢复与真实MCP1→0成立，最终报告BLOCKED；Attempt/Call详见p0/results.json与关联诊断。
- P0 F：started=false，cleanup UNKNOWN；本轮没有实际工具容器启动，不能给出容器exit/digest实际拉取证明。image配置锁定digest见environment，镜像本地可用性未验证。
- code_repair真实API/PG/Worker尝试：Task `6ddf2459-ffa2-4caf-9e32-a3806a705e63`，Attempt `a84f8451-4125-4585-bc78-f55320b0d3b6`，ToolCall `b414a401-cef0-4174-807d-a8da8a02fec1`，Verification `acb7b3de-3e69-4302-99b6-087ce9e81b46`。基线NOT_RUN，Runtime FAILED/BASELINE_NOT_CONFIRMED，Candidate无，真实模型调用0。
- 该基线Artifact `618711bf-d824-4964-b576-dc3681dc51e2`，2147 bytes，SHA-256 `fa4e5ac1218ffc6c0b3154b8d87280c83c1788e07d3b33af7325da96dc165234`；API字节与PG读取一致。**这是环境失败证据，不是修复后的最终patch。**
- 持久补丁恢复探针 Task `77322009-8322-4815-845c-61e17b120cec`：candidate1，两个Attempt，第一次exit-9、replacement0，原ToolCall/patch/已提交Step保持不变。Artifact hash `68e862446be579c6115290fc2ab9ff3df6cdee0f3eb195aa8352b34de42355c6`。明确合成存储fixture，未执行候选，结果UNRESOLVED，不算模型修复或验证PASS。

## 反例审查

inspect权限/超时/解析失败不能报ABSENT；报告缺失/空测试/skip/nonce/hash/task/candidate错配不能PASS；API202只记录受理；Fake标识独立且真实组不接收Fake；旧Attempt写回与取消后DELIVERED受PG锁和fence控制。相关测试及原始输出在tests与reports。仍不能证明任意恶意Python无法篡改同解释器runner；见threat_model。Hash证明一致性不是真实性。

## 人工边界与恢复

Docker需环境所有者提供已获准daemon访问的会话；本轮未提权、未改组/权限、未清未知资源。模型需指定受支持后端/模型、可信秘密变量与正的请求/token/费用预算；未读取偶然存在的key。两项最小动作和复跑命令见blockers.md。

本会话启动的API/业务服务/PG已停止，端口18081/18082/55439均不监听，DB文件保留；resource-cleanup.json记录实际PID与检查。没有后台自动续跑。唯一恢复入口resume.md。下一步先真实P0与人工patch验证，再接模型smoke和有界循环故障证据；独立判分先行才能防止旧PASS与测试未运行被误算修复。
