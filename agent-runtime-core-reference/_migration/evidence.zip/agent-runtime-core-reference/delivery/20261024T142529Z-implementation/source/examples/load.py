"""270 unique submissions, explicit overload classifications; no 202-as-success shortcut."""

import argparse
import asyncio
import json
import time
from pathlib import Path
from uuid import uuid4

import httpx

from config.settings import settings
from examples.demo import worker
from runtime.tools.docker_backend import DockerBackend


async def run(execute):
    state = json.loads(await asyncio.to_thread(Path("TASK_STATUS.json").read_text))
    out = Path("reports") / state["run_id"] / "benchmarks"
    out.mkdir(parents=True, exist_ok=True)
    plan = {
        "kind": "deterministic_document_review_runtime",
        "concurrency": [1, 5, 10],
        "rounds": 3,
        "submissions_per_round": 30,
        "total": 270,
        "planner": "deterministic",
        "admission_limit_per_principal": 3,
        "rate_limit_per_minute": 30,
        "note": "overload refusals are counted separately, never mixed into successful latency",
    }
    available = await DockerBackend().availability()
    if not execute or not available["available"]:
        plan.update(
            status="BLOCKED" if not available["available"] else "NOT_RUN", actual_submissions=0
        )
        (out / "load_not_run.json").write_text(json.dumps(plan, indent=2))
        print(json.dumps(plan))
        return
    raw = out / "load_raw.jsonl"
    if raw.exists():
        raise RuntimeError("choose new run_id; no evidence overwrite")
    async with httpx.AsyncClient(
        base_url="http://127.0.0.1:18081",
        trust_env=False,
        headers={"Authorization": "Bearer " + settings.user_token.get_secret_value()},
        timeout=10,
    ) as client:
        for concurrency in (1, 5, 10):
            for repeat in range(1, 4):
                semaphore = asyncio.Semaphore(concurrency)

                async def task(index, semaphore=semaphore, concurrency=concurrency, repeat=repeat):
                    async with semaphore:
                        identifier = str(uuid4())
                        tick = time.monotonic()
                        response = await client.post(
                            "/tasks",
                            headers={"Idempotency-Key": identifier},
                            json={
                                "document_id": "DOC-002",
                                "session_id": identifier,
                                "budget_ms": 120000,
                            },
                        )
                        result = {
                            "submission_id": identifier,
                            "index": index,
                            "concurrency": concurrency,
                            "round": repeat,
                            "http_status": response.status_code,
                            "task_id": None,
                            "status": "REJECTED",
                            "execution_seconds": None,
                        }
                        if response.status_code == 202:
                            task_id = response.json()["task_id"]
                            result["task_id"] = task_id
                            await worker(task_id, out)
                            diag = (await client.get(f"/tasks/{task_id}/diagnostics")).json()
                            result["status"] = diag["task"]["status"]
                            result["diagnostics"] = diag
                        else:
                            result["rejection"] = response.json()
                        result["submission_wall_seconds"] = time.monotonic() - tick
                        with raw.open("a") as stream:
                            stream.write(json.dumps(result) + "\n")

                await asyncio.gather(*(task(i) for i in range(30)))
    (out / "load_config.json").write_text(json.dumps(plan, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    asyncio.run(run(parser.parse_args().execute))
