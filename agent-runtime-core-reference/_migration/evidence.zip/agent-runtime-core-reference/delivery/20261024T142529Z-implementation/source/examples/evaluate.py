"""Pre-register model/load experiment slots; execution requires explicit --execute."""

import argparse
import asyncio
import json
from pathlib import Path
from uuid import uuid4

import httpx

from config.settings import settings
from examples.demo import worker
from runtime.tools.docker_backend import DockerBackend


def slots():
    return [
        {"case_id": f"case-{case:02}", "group": group, "round": repeat, "strategy": strategy}
        for group, strategy in [("A", "single"), ("B", "context"), ("C", "loop")]
        for repeat in range(1, 4)
        for case in range(5, 13)
    ]


async def run(execute):
    state = json.loads(await asyncio.to_thread(Path("TASK_STATUS.json").read_text))
    out = Path("reports") / state["run_id"] / "benchmarks"
    out.mkdir(parents=True, exist_ok=True)
    docker = await DockerBackend().availability()
    authorized = (
        settings.model_enabled
        and settings.model_request_limit > 0
        and settings.model_token_limit > 0
        and bool(settings.model_name and settings.model_budget_id)
    )
    reasons = []
    if not docker["available"]:
        reasons.append("DOCKER_UNAVAILABLE")
    if not authorized:
        reasons.append("MODEL_AUTHORIZATION_OR_BUDGET_MISSING")
    if not execute:
        reasons.append("EXECUTION_NOT_REQUESTED")
    plan = {
        "model": settings.model_name or None,
        "model_requests_limit": settings.model_request_limit,
        "model_tokens_limit": settings.model_token_limit,
        "fake_results_allowed": False,
        "planned_real_tasks": slots(),
        "planned_load": {
            "concurrency": [1, 5, 10],
            "rounds": 3,
            "tasks_per_round": 30,
            "total": 270,
        },
        "load_status": "NOT_RUN",
        "load_reason": "see examples.load and its separate load_not_run/load_raw evidence",
        "blocking_reasons": reasons,
        "model_observed_tasks": 0,
    }
    if reasons:
        (out / "not_run.json").write_text(json.dumps(plan, indent=2))
        print(
            json.dumps(
                {
                    "planned_model_tasks": 72,
                    "actual_model_tasks": 0,
                    "planned_load_tasks": 270,
                    "actual_load_tasks": 0,
                    "reasons": reasons,
                }
            )
        )
        return
    raw = out / "model_raw.jsonl"
    if raw.exists():
        raise RuntimeError("refusing to overwrite model evidence")
    async with httpx.AsyncClient(
        base_url="http://127.0.0.1:18081",
        trust_env=False,
        headers={"Authorization": "Bearer " + settings.user_token.get_secret_value()},
    ) as client:
        for slot in slots():
            response = await client.post(
                "/tasks",
                headers={"Idempotency-Key": str(uuid4())},
                json={
                    "task_type": "code_repair",
                    "case_id": slot["case_id"],
                    "session_id": str(uuid4()),
                    "planner_mode": "real",
                    "repair_strategy": slot["strategy"],
                },
            )
            response.raise_for_status()
            task_id = response.json()["task_id"]
            await worker(task_id, out, wait_seconds=135)
            response = await client.get(f"/tasks/{task_id}/diagnostics")
            response.raise_for_status()
            diag = response.json()
            with raw.open("a") as stream:
                stream.write(json.dumps({**slot, "task_id": task_id, "diagnostics": diag}) + "\n")
            plan["model_observed_tasks"] += 1
            if diag["task"]["error_code"] in {
                "MODEL_BLOCKED",
                "MODEL_BUDGET_EXHAUSTED",
                "REPAIR_GENERATION_FAILED",
            }:
                break
    (out / "model_config.json").write_text(json.dumps(plan, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    asyncio.run(run(parser.parse_args().execute))
