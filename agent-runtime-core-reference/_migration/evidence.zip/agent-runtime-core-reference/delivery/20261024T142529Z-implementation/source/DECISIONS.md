# 决策记录

- 2026-10-24：新主任务书取代旧文档限定，缺失旧附件不再阻塞。保留历史报告原件。
- Git自身及父级无仓库，已有本地身份；授权建立独立本地基线，忽略运行环境、报告、大数据与秘密，不设远端。
- 继续现有checkpoint/Ledger/Session事务语义，新增功能经现有Kernel/ToolRuntime/Store/Worker集成。
- 只有真实沙箱才能执行候选；数据校验、AST读取和报告反例单测可离线执行。

- 保留固定 Python 3.11.17 slim digest，使用 stdlib unittest 可信 runner；不增加镜像构建或 pytest 依赖。case snapshot_hash 不伪造 Git revision。
- v1 Patch 使用唯一 exact replacement；批准既有源码文件最多3个、200变更行、32KiB。可信平台校验后才能持久化。
- Verdict 状态遵循新主契约 ERROR/NOT_RUN/INCOMPLETE，不回写旧方案 INVALID。实际基线未运行时不生成候选。
- 模型接口沿用 httpx 锁文件直接 Responses REST，Fake 明确分离。没有真实授权/预算/密钥则不调用；不自动回退。预算预留持久化且未知调用不退款。
- 无需新持久层：repair_candidates/repair_verifications 和模型预算表置于同一个 PostgreSQL，候选/Step/Artifact/Session/Ledger原checkpoint事务一起提交。验证缓存关闭。
- 连接池每进程4连接/16等待/2秒超时，跨进程受理仍由数据库限额决定；实验等待实际受理窗口，不放宽配额。
- 容器 UNKNOWN 不等于清理成功；实际权限未改变。14个 Docker pytest skip 全部列 BLOCKED。
- 正式学习工程和 month 目录未读取/复制/修改。没有推送、PR、安装daemon、付费模型调用。
- 受控教学威胁模型不声称抵抗任意恶意 Python 修改同解释器 runner；hash只证一致性。外部最终验收与个人掌握均由独立复核方判断。
