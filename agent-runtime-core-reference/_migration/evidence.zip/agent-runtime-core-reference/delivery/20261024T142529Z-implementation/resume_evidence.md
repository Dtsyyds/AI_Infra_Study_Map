# 简历证据草稿（待本人独立复核）

可用定位：Agent Runtime Core — Reliable Coding Task Execution，个人学习参考项目，Codex 辅助实现。不得写成公司实习、生产服务或公开 benchmark。

可陈述的工程事实：

- 在现有六层 Python/PostgreSQL Runtime 内实现严格 CaseManifest、独立 Verdict、持久候选/验证关联、最多三候选控制器、AST 上下文与受限结构化模型 Adapter；用事务、租约/fence、ToolCall 身份处理恢复。真实修复成功尚无证据。
- 本地实际运行 PostgreSQL/MCP/独立 Worker 故障探针，保存命令、原始输出、JUnit、Task/Attempt/ToolCall 与 Artifact hash。数字以 delivery 的 tests 与 benchmarks 原始数据重算，不把局部恢复当完整审核成功。
- 修复 Docker inspect 错误误判清理问题，增加未知状态拒绝规则及反例测试。真实容器权限仍 BLOCKED，不能宣称生产级沙箱可靠性。

禁止填写的数字：真实模型修复率/成本下降/吞吐提升/P95改善/完整270任务成功率。目前真实模型调用与270提交均为0；原始计划不是实验结果。测试总数请引用本次 FINAL_REPORT 及 JUnit，不将多轮重复执行简单相加成独立覆盖。

所有数字来源 run：20261024T142529Z-implementation。岗位映射见 job_requirements_matrix.md。个人独立实现与算法、OS、网络、DB、模型、表达能力：NOT_ASSESSED。最终验收：外部复核待进行。
