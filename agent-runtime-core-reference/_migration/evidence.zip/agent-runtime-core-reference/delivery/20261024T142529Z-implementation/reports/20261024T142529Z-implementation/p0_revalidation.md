# P0 实际复验：BLOCKED

命令、开始结束时间、退出码与执行时源码快照见 commands.jsonl 的 p0-revalidation 记录；原始输出 p0-revalidation-143534161741.log。命令为 `.venv/bin/python -m examples.p0_revalidate`，包装器退出0只表示证据采集完成，不表示P0通过。

Docker客户端29.9.1可用，default context、socket0660/root:983、uid1000未获权限，daemon permission denied。未提权或放宽权限。固定配置镜像为 python:3.11.17-slim-bookworm@sha256:f06d01d4ba3f8ad5af45a3ec87df19c1d317d8e8961edc0fabda61811af6f7cf；本地存在/实际运行digest无法核验。

A：DOC001 Task70fbe9b5-e3b1-44fa-8e62-84b06d5f20ae、DOC002 Task47967af1-2ee0-478c-8c35-326d320b6eb1，真实Worker均在Docker检查处FAILED，checkpoint0；最终报告/Artifact MISSING。MCP标记计数0为已缓存读取，不宣称冷MCP流程通过。

C：Taska75e971c-e713-444e-aa52-6d6cfa4d2b1f，真实独立Worker被杀后接管；MCP读取1→0、原完成Step/Call未重复。最后仍DOCKER_UNAVAILABLE，完整报告BLOCKED。Attempt/ToolCall完整值见p0/results.json及p0/<task>.json。

F：无容器启动标记，started=false、cleanup=UNKNOWN，不能宣称超时终止或归属清理通过。inspect错误不再被误报ABSENT，数据协议反例已测试，实际清理尚未验证。

后续code_repair仅产生NOT_RUN基线Artifact，不替代A/C最终审核报告。参阅FINAL_REPORT.md。所有历史报告保留，没有拼接旧任务ID补足本轮证据。
