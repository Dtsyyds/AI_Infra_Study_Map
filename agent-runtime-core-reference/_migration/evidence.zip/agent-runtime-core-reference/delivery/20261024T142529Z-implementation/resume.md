# 唯一恢复入口

状态：PARTIAL / BLOCKED，当前执行会话已完成安全实施、自测及证据打包，不会自动在后台或下一会话继续。

1. 工作区仅 `/home/dts/agent-runtime-core-reference`。读取 CODEX_MASTER_PLAN.md、TASK_STATUS.json、blockers.md、最新 delivery/20261024T142529Z-implementation/FINAL_REPORT.md。最终源码commit/hash见同目录source_manifest.json。正式学习工程和month目录未访问/修改。
2. 已有实现：Manifest/独立Verdict/范围受限patch/可信runner/12合成例/AST上下文/Fake与真实Adapter/持久预算与最多三候选/PG恢复/API/CLI/资源上限/Docker UNKNOWN修复。文件映射docs/implementation_mapping.md。没有已验证的真实修复DELIVERED。
3. 最近全量回归：ae3db9c代码，132 passed、14 Docker skipped；Ruff通过；mypy76文件通过。reports/20261024T142529Z-implementation含每次命令、失败原件、源码hash、140条有明确范围的故障数据、P0 BLOCKED和实际Artifact。后续只改文档/打包工具；打包检查运行代码与测试快照一致。
4. 本会话启动的API/业务进程1430435/1430436已停止，项目PG已停止，18081/18082/55439未监听；.pgdata保留，资源检查见resource-cleanup.json。无候选容器启动，无付费模型调用。需要运行PG测试时先make db-start / make start，不要重新initdb既有库。
5. 下一步最小工作：由环境所有者给出已授权Docker会话；选择新UTC run_id，保留旧报告，复跑P0 A/C/F和12例原始/人工patch。容器运行失败先定位修复，不以宿主执行代替。再补测试运行中/结果提交后退出和容器5类×5次证据。
6. 模型只有在明确后端/模型/秘密变量和正预算授权后使用，先dev单例真实smoke；没有授权保持BLOCKED，绝不静默Fake。之后完成72真实任务和270确定性负载，各自统计分母/成本/队列与执行时间；待补项在blockers与TASK_STATUS中。
7. 复现命令见REPRODUCE.md。打包用examples.package_delivery（拒绝覆盖既有包）；若继续修改，应新run和新包，不重写现有证据。无需逐切片批准；权限/密钥/费用/不可逆事项仍是人工边界。

最终复核交给ChatGPT/独立评审，本代理不代为验收，也不替本人证明已独立掌握代码。
