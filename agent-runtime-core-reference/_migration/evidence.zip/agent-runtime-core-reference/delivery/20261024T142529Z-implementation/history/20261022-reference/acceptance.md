# 本轮实际验收记录

结论：**部分实现已实测，完整 document_review 尚未跑通。** Docker socket 权限被拒绝，未修改用户组/socket、未使用 sudo、未开放公网或放宽容器权限。没有把宿主脚本、Mock 或接口存在当成容器验证。

这是 Agent Runtime Core Reference 教学实例，不是生产平台；不计入正式学习工程进度，不构成正式 W8 验收。

## 文件与执行环境

初始工作区 `/home/dts/agent-runtime-core-reference` 为空且不是 Git 仓库；没有适用 AGENTS.md。新建的82个项目文件（含包标识、源码、测试、部署与学习文档）及哈希见 [file-manifest.json](file-manifest.json)。另保留独立 `.python`、`.venv`、`.postgres`、`.pgdata` 与 `reports/`。没有修改、复制或 import 正式 agent-runtime-core/month01–month04 源码；没有 Git 提交、推送或 PR。

实际 Python **3.11.17**，PostgreSQL **17.11**（本地专用二进制，真实数据库），MCP SDK/Types **2.2.0**，实际协议 **2026-07-28**、真实 stdio。Docker Client **29.9.1**；Daemon 无权访问，不能报告其服务端版本或容器运行成功。锁定依赖已经重新安装核验。版本、公开注册表镜像 digest、环境异常与修复见 [environment.json](environment.json) 和 [image-manifests.json](../image-manifests.json)。Compose 未执行。

## 最终测试

最终 `make check`：Ruff 通过；项目范围 mypy **46个源文件通过**；pytest **48 passed / 0 failed / 2 skipped**。两项 skipped 的原因都是基础设施 BLOCKED：普通 skipped=0，blocked=2。

| 分类（按目录） | passed | failed | 普通 skipped | blocked |
|---|---:|---:|---:|---:|
| docker | 3 | 0 | 0 | 2 |
| integration | 17 | 0 | 0 | 0 |
| mcp | 6 | 0 | 0 | 0 |
| process | 5 | 0 | 0 | 0 |
| unit | 17 | 0 | 0 | 0 |

Docker目录的3个passed是命令构造、测试开关拒绝和宿主固定脚本字段单元测试，**都不是容器执行**。两个真实Docker测试因权限阻塞。process测试的C证明独立进程恢复语义，不表示最终业务报告完成。

真实结果文件：[test-results.xml](test-results.xml)、[test-results.json](test-results.json)。命令、UTC开始时间、耗时、退出码和输出文件见 [commands.log](commands.log)。最终 Ruff/mypy/pytest 输出使用带时间后缀的文件，不覆盖早期失败。

## A–G 实际演示

统一命令 `make demo` 已执行。完整结果、所有任务/Attempt/Tool Call ID、条件屏障、检查项和进程日志路径见 [demo-results.json](demo-results.json)。

| 场景 | 结果与Task ID |
|---|---|
| A DOC-001 | BLOCKED；`a184eb90-23d6-4e21-839c-16ce90912191`；已检索规则、读取资料并提交Step 0，随后FAILED/DOCKER_UNAVAILABLE。没有最终报告或完整流程Artifact。预期业务结论只是待验证目标，不是实测输出。 |
| A DOC-002 | BLOCKED；`ea3128ff-03d1-4e5e-9f5a-6df5ddb3032f`；已检索规则、读取资料并提交Step 0，随后FAILED/DOCKER_UNAVAILABLE。没有最终报告或完整流程Artifact。预期业务结论只是待验证目标，不是实测输出。 |
| B 幂等 | PASS；`828d9450-9997-4823-a5b1-bdc7cdba3ced`；同键同请求同Task、不同请求409、逻辑任务1个。 |
| C 崩溃恢复 | 恢复断言PASS，完整报告BLOCKED；`26615510-c5c3-4f7d-9aa5-4b8d97844e49`；首次MCP实际读取1次、替代Worker读取0次；Step/Tool Call身份不变、Attempt改变。 |
| D 幂等 | PASS（局部发布探针）；`d673d902-7e3e-4482-a453-ebc33342f770`；独立业务schema记录2次请求/1次效果。 |
| D 不安全 | PASS（局部发布探针）；`3061ca1a-30ba-4a3b-8648-21c611a936d1`；独立业务schema记录1次请求/1次效果。 |
| D 可查询 | PASS（局部发布探针）；`402a7f2d-5512-4b7c-980f-16fdc0e4ed60`；独立业务schema记录1次请求/1次效果。 |
| E 租约竞争 | PASS；`dc347f22-1874-4e97-bf6a-19aa4981b77a`；两个Worker竞争单次初始claim；SIGSTOP后租约自然到期，替代者接管，旧Worker恢复写回拒绝。 |
| E SSE | PASS；`36f87edb-6801-42a2-ae64-c377917fbd5f`；断线不取消、相同版本不重复进度、超前Last-Event-ID返回400。 |
| E 取消提交顺序 | PASS；先取消 `6f1082fe-8efe-4c26-befa-647a6c5af22c` 最终CANCELLED；先成功 `b1667048-38fe-4353-ab52-646210a9c3b4` 保持SUCCEEDED；明确为终结事务探针。 |
| F 权限/审计/秘密 | 局部PASS；拒绝 `4e7fbe5a-5794-4e3d-b1d0-a0b272df9eb1`、审计故障 `6dc2d388-1aa5-4233-9379-9ea492d3688f` 均0派发/0外部请求；秘密保护 `8125e1c8-3c7b-480d-b581-c7f61dceb70f` 经真实MCP，diagnostics/audit/Trace不含模拟秘密。容器真实超时/终止BLOCKED。 |
| G 上下文 | PASS；`9419b8c1-d43f-4687-97fc-d925d43da998`；60条历史压缩、规则与资料事实保留、错误摘要被拒绝、新Attempt从Checkpoint重建。G重建在同测试进程，独立Worker恢复另由C证明。 |

D 使用 `tests/fakes/publish_probe.py` 和显式测试Report，单独验证 L2/L3 外部副作用窗口；它不是完整document_review。业务服务是独立进程、独立连接/事务，效果先提交再以数据库屏障暂停响应。unsafe第一次恢复为UNKNOWN/NEEDS_REVIEW且无第二次请求；随后测试运维身份执行INCONCLUSIVE和CONFIRMED_APPLIED的CAS对账，恢复后仍无新增派发。

## 关键不变量逐项结论

“成立”仅指下列实现和已运行断言覆盖的条件，不是对任意故障的可靠性证明。

| 编号 | 结论 | 证据/边界 |
|---:|---|---|
| 1 | 实现成立；JSON边界与白名单路径已测 | DB保存DTO/JSON/版本/结果，不序列化活Task/Lock等；AST层次检查通过。 |
| 2 | 已测成立 | RequestContext/Task/Attempt分离，真实SSE断线后Task仍QUEUED且cancel_requested=false。 |
| 3 | 已测成立 | 同事务受理/幂等；202之后可读；并发重放同Task，不同请求409。 |
| 4 | 已测成立 | 真正Attempt INSERT触发器失败，Task仍QUEUED、fence未增且无Attempt。 |
| 5 | 已测成立 | Plan随机UUID，Action+PREPARED同事务；C/D跨Attempt工具身份稳定；改已保存Action被拒绝。 |
| 6 | 已测事务边界成立 | C真实MCP读取1→0；Checkpoint/Step/Session/Artifact同事务；完整标准审核Artifact仍受Docker阻塞。 |
| 7 | 已测租约时间成立 | timestamptz、连接时区UTC；取得行锁后再读DB当前时间，长锁等待测试拒绝过期写回。 |
| 8 | 已测成立 | 严格整数1000–1800000；服务端deadline，含排队；reconcile不重置。 |
| 9 | 已测成立 | 过期claim不创建Attempt；未确认外部效果先UNKNOWN/NEEDS_REVIEW。 |
| 10 | DB fencing/旧进程拒写已测；容器停止未测 | 心跳异常停止活执行与新动作；真实容器尽力终止路径BLOCKED。租约不能撤销已发外部HTTP请求。 |
| 11 | 局部真实副作用路径已测成立 | LOCAL_TRANSACTIONAL同库原子；幂等原键2/1；queryable肯定查询1/1；unsafe UNKNOWN禁重发1/1。 |
| 12 | 已测事务边界成立 | 运维静态身份、CAS、证据SHA-256摘要、追加审计，三种结论；取消/到期及其他未确认效果阻塞检查。 |
| 13 | 已测成立 | 幂等优先、同principal/session活动任务排他；NEEDS_REVIEW保留会话/配额。 |
| 14 | 已测基础/重连/断流条件成立 | 最新一致快照，每秒轮询；首次快照、不变不重复、漏版本reconciled、非法/超前400；不承诺事件历史。 |
| 15 | 已测成立 | PostgreSQL BYTEA；单件2MiB、Task8MiB、平台512MiB；事务行锁配额、超限不提交步骤，无持久文件Artifact。 |
| 16 | 实现但未获真实验证 | Docker名称+标签识别、逐容器查有效Attempt；真实遗留清理及不误杀有效容器BLOCKED。 |

## 阻塞、缩减与观测缺口

- 真实Docker容器没有启动，实际资源隔离、进程终止、遗留清理未验证；A无法生成最终报告，不能宣称完整闭环通过。
- 使用确定性规划器；没有真实模型推理。会话记忆仅支持同Task跨Attempt，不自动继承不同Task历史。
- 幂等HTTP网络错误当前保守进入NEEDS_REVIEW，没有自动重试调度；已测的是崩溃后稳定原键恢复。
- 脱敏只保证明确测试样例，不是任意秘密检测保证。Audit表追加限制不防数据库超级用户。数据库整体不可用时可能无法持久记录拒绝审计。
- 270次压测、全部10/30次重复实验、数据库故障转移/磁盘损坏/任意网络组合均未执行。
- 最早工作区探测及依赖bootstrap在记录器建立前执行，不能声称commands.log包含所有最初shell调用；环境记录保留原因，锁定依赖已再次实装核验。早期同名日志的一个mypy通过输出从真实工具输出恢复并注明来源；之后日志文件改为唯一名称。
- 保留首次失败：ROS PYTHONPATH污染、初次迁移依赖问题、MCP stderr捕获问题、Ruff/mypy问题和images辅助命令的类型错误；已修复，未删除失败测试或降低断言。

## 启动、持久性复查与停止

实际运行过 `make db-start`、`make migrate`、`make start`、`make check`、`make demo`、`make stop`、`make db-stop`。服务只绑定127.0.0.1；API18081、模拟业务18082、数据库55439。`make images`实际返回2/BLOCKED，未执行Docker拉取或容器启动。

数据库完整停止再启动后，15个本轮演示任务仍可查询，三种外部效果计数不变，见 [restart-verification.json](restart-verification.json)。报告文件不参与Runtime恢复。

**退出状态：全部本轮服务已停止，数据库文件已保留。** API最后PID775061、模拟业务最后PID775062已停止；Worker/MCP/probe无残留；18081/18082/18084/55439均未监听。工具容器创建数为0。详见 [cleanup.json](cleanup.json)。准确停止命令是 `make stop`（仅本项目记录的服务）与 `make db-stop`（仅本项目.pgdata）；不删除演示数据库，不做全局Docker清理。

第一次阅读从 [core/kernel.py](../../core/kernel.py) 的 `Kernel.run` 开始，随后按 [source_reading_order.md](../../docs/source_reading_order.md) 的12个文件阅读。六份中文学习文档和README引用实际符号，区分已实测、未实测及主动缩减。
