# P0 复核记录

**结论：P0 未实际通过，A/C/F 因 Docker socket 权限 BLOCKED。** 本轮已完成源码/历史证据核对，并真实复现既有 `tests/unit`：17 passed，0 failed/error/skipped。没有把单元测试、静态参数或历史局部发布探针算作完整标准审核验收。

run_id：`20261024T135237Z-enhancement-p0`；开始探测 UTC 2026-10-24 13:52:37（Asia/Shanghai 21:52:37）。工作目录 `/home/dts/agent-runtime-core-reference`。Git commit **MISSING**，不是 Git 仓库；适用 AGENTS.md 未找到。缺失方案附件的核对仍为 MISSING。

## 环境与原始记录

| 项目 | 实际观察 |
|---|---|
| OS | Linux 6.14.0-37-generic，x86_64；完整 platform 见 environment.json |
| 用户 | uid=1000(dts)，gid=1000；组中不含 983；完整 `id` 见 identity.log |
| Python | 工程 `.venv/bin/python` 3.11.17 |
| 包版本 | pytest 9.1.1、mcp/mcp-types 2.2.0、psycopg 3.3.6、pydantic 2.14.1、fastapi 0.159.1；来自本地 metadata，本轮不升级依赖 |
| Docker client | 29.9.1，build dfc520d |
| 已配置 context | `docker context ls` 仅返回当前 default，endpoint `unix:///var/run/docker.sock`；未切换 context |
| Docker 实际后端 | `DockerBackend._docker` 使用临时空 CLI 配置并固定 DOCKER_HOST=`unix:///var/run/docker.sock`；不会自动使用另一个用户 context |
| socket | `srw-rw----`，uid=0、gid=983；当前用户 read/write 均 false |
| daemon | 实际 `docker version --format '{{json .}}'` 退出 1；Server=null；stderr 为 permission denied。不能由此推断 daemon 是否健康 |
| 工具镜像配置 | `python:3.11.17-slim-bookworm@sha256:f06d01d4ba3f8ad5af45a3ec87df19c1d317d8e8961edc0fabda61811af6f7cf` |
| 已安装/实际运行镜像 | **MISSING/BLOCKED**，未能 inspect/pull/run；上述仅源码固定引用，不是本轮使用的镜像证据 |
| PostgreSQL/API/Worker | 本轮未启动或连接数据库、API、业务服务或 Worker；未修改既存数据库数据。历史 PostgreSQL 17.11 不能当本轮存活证据 |

`environment.json` 保留环境与清单摘要；`environment-versions.log` 保留本地版本。没有读取 Docker registry 凭据、生产密钥或模型凭据。

## 实际执行命令与退出码

[commands.log](commands.log) 保存以下受记录命令的完整 argv、UTC 开始时间、持续时间、退出码和原始输出文件。最初的 `pwd`、文件列举、源码阅读与生成报告所用内联脚本在记录器建立前/之外执行，保留于会话工具记录；不宣称 commands.log 覆盖全部 shell 调用。

| 命令/探测 | 退出码 | 原始输出 / 解释 |
|---|---:|---|
| `git status --short` | 128 | git-status.log；非 Git 仓库 |
| `git rev-parse HEAD` | 128 | git-head.log；commit MISSING |
| `id` | 0 | identity.log |
| `docker --version` | 0 | docker-client.log |
| `docker context ls --format '{{json .}}'` | 0 | docker-contexts.log |
| 项目 Python 调用 `DockerBackend.availability()` | 0 | docker-project-endpoint.log；返回 available=false。Python 正常返回不代表 Docker 成功 |
| 项目 Python 调用 `_docker('version','--format','{{json .}}')`，以 docker 返回码退出 | 1 | docker-raw-version.log；原始 Client/Server/stdout/stderr |
| 项目 Python 本地版本查询 | 0 | environment-versions.log |
| 下列 pytest 命令（经 examples.record） | 0 | pytest-unit.log、test-results.xml |

本轮复现命令原文：

```bash
env -u PYTHONPATH PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m examples.record \
  --run 20261024T135237Z-enhancement-p0 --name pytest-unit -- \
  .venv/bin/python -m pytest -q -rs -p no:cacheprovider tests/unit \
  --junitxml=reports/20261024T135237Z-enhancement-p0/test-results.xml
```

输出 `17 passed in 0.43s`。这 17 项含 Kernel Fake/契约/上下文/安全/遥测单元断言，仅证明其覆盖条件；没有新的 MCP、数据库、容器或独立 Worker 集成结果。`test-results.json` 分别标注 `historical` 与 `current_unit_only`，不得相加成新一轮通过数。没有运行 `make check`、`make demo`、Docker 测试或宿主检查脚本替代容器。

## A/C/F 完整链路判定

| 场景 | 本轮执行 | 判定 | 新 task_id / attempt_id / tool_call_id |
|---|---|---|---|
| A DOC-001 → 最终 NEEDS_DOCUMENTS + BYTEA | 未提交；前置 Docker 检查失败即停止 | BLOCKED，预期结论未经本轮实测 | MISSING（未创建） |
| A DOC-002 → 最终 PASS + BYTEA | 同上 | BLOCKED | MISSING（未创建） |
| C 已提交 checkpoint → 独立 Worker 退出 → 新 Worker → 最终报告 | 未启动 Worker；不重复制造已知无法完成的链路 | BLOCKED | MISSING（未创建） |
| F 脚本真实启动 → 墙钟超时 → 容器终止及归属清理 | 未创建容器或执行探针 | BLOCKED | MISSING（未创建）；现有直接 Docker 测试本来也未绑定持久 Task/Ledger |

本轮实际 MCP 读取次数没有 A/C 运行样本，记 **N/A（未执行）**，不是“已测零次重复”。容器启动标记、退出状态、die/destroy 事件、归属清理结果和最终 Artifact 字节/hash均 **MISSING**。本轮没有创建容器，不能因此宣称既存容器已清理；daemon 不可访问，既存资源状态未知。

## 旧证据独立复核，不计入本轮通过

旧目录 `../20261022-reference/` 的 XML 为 48 passed / 2 infrastructure skipped；JSON 为 48 passed / 2 blocked。acceptance 与 demo JSON 的 A/C ID 不一致，详见 [基线](../../docs/enhancement_baseline.md)。

当前旧 demo JSON 的 A DOC-001 task `b80034b3-af51-4d58-83a9-7c57d06ebbf9`，Attempt `ed5bfff6-bde8-466d-8688-5e49adad6b93`，fetch/check IDs 为 `e66ac05b-3526-4783-9826-53012fd5e3c3` / `a4e3e7ad-e458-4142-a6d7-aabac56d899a`。DOC-002 task `fe8b82cd-9bae-4a01-b7be-cb030b9a96db`，Attempt `99dd6d35-c7ec-4e09-a4ac-30e2ec8b9702`，fetch/check IDs 为 `5952bf32-d14a-422a-830f-7def8a9348b1` / `cd776421-9a2d-4840-b7b2-b03a3da0ee55`。二者 Artifact 均为空，Worker 日志读取标记均 0；不能算该批真实 MCP 冷读取通过。

旧 C task `84ba5834-add8-4616-9482-caf12c499ca7`，Attempts `8ea0fb9e-608e-49d1-b85e-320ec0c602c9` / `bd035b0e-3c71-4f18-be25-d1a1c0839a9a`，已完成工具 ID `5418ab24-ad0a-4c91-b3d3-1e83e51832de`。从旧日志重新统计 MCP 标记为 1→0；最终仍 FAILED、完整报告 blocked。这是历史局部恢复证据，不是本轮执行。

[historical-evidence-check.json](historical-evidence-check.json) 保留来源路径、真实 ID、计数、日志 hash；未生成最终 Artifact hash，因为对应字节不存在。

## 阻塞处理与后续复验入口

最小环境前提：由环境所有者提供**已经批准、能够访问项目固定本地 daemon 的执行身份/会话**，允许检查固定镜像、创建上述受限工具容器、读取状态/事件及仅清理已核实归属的本项目工具容器；镜像缺失时需允许拉取此固定 digest。当前实现不支持自动切换到 rootless/其他 context，不能静默替换 endpoint。

本轮停止在权限边界，没有申请或执行 sudo、改组、chmod 666、socket 挂载、未认证网络接口等变更。环境授权时间等待不能视为授权。若只有其他 daemon 可用，应先单独审查配置适配，不在本轮绕过现有边界。

环境恢复后的计划（**以下未执行**）：

1. 在独立新 run_id 中再次检查实际 endpoint、镜像 inspect digest、数据库与端口归属；只启停本项目服务，保留原有运行者资源。按需使用 `make db-start`、`make start`，不默认重迁移/重建既存数据。
2. 用既有 `examples.demo.normal` 和 `examples.process_scenarios.crash_checkpoint` 作为 A/C 入口；先落实计划 R01/R02 的完整证据采集，最终读取 Artifact API 字节，与 PG BYTEA、result 比对并计算 SHA-256。确保独立 MCP 日志计数及缓存策略可见。
3. F 入口 `tests/docker/test_backend.py::test_real_timeout_reaches_process_barrier_then_container_is_gone`；先落实 R03/R04 的真实退出证据和 fail-closed 检查。不能只调用 `examples.demo.security` 或用 CLI 退出代替容器结束。补齐有效/失效 Attempt 与未知归属的清理实验。
4. A/C/F 每次保留 Task/Attempt/Step/tool_call 映射（直接 Backend 探针明确 N/A）、原始输出/退出码、运行镜像 digest、启动标记、清理记录、Artifact；按单轮证据产生新 acceptance。仍失败则保留 FAILED/BLOCKED，不改旧断言压低门槛。

代码问题、最小修改建议及验收拆分详见 [基线 B01–B08](../../docs/enhancement_baseline.md) 和 [实施计划](../../docs/enhancement_plan.md)。本轮未进行这些修补。

## 本轮变更与收尾

新增 `docs/enhancement_baseline.md`、`docs/enhancement_plan.md`、本记录及同目录原始日志/JSON/XML/文件 hash 清单。未修改既有源码、测试断言、配置、依赖或历史报告。未启动服务，无需停止本轮服务；不触碰用户既存进程。前后文件核对见 [workspace-changes.json](workspace-changes.json)，证据完整性见 [evidence-sha256.json](evidence-sha256.json)。正式学习工程明确未修改。
